package com.twelveaxes;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class QuizResultPayloadTest {
    // Vetor de 12 eixos no formato aceito por /api/results/by-axes.
    private static final String VETOR = "72,72,72,72,72,72,72,72,72,72,72,72";

    @Autowired
    private MockMvc mockMvc;

    @Test
    void sharedResultCarriesEveryNewSection() throws Exception {
        mockMvc.perform(get("/api/results/by-axes").param("v", VETOR))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.axes.length()").value(12))
                .andExpect(jsonPath("$.matches.length()").value(4))
                .andExpect(jsonPath("$.bottomIdeologyMatch.ideologyId").isNotEmpty())
                .andExpect(jsonPath("$.topCountryMatch.historical").value(false))
                .andExpect(jsonPath("$.topHistoricalCountryMatch.historical").value(true))
                .andExpect(jsonPath("$.countryDimensionMatches.length()").value(3))
                .andExpect(jsonPath("$.countryDimensionMatches[0].dimension").value("political"))
                .andExpect(jsonPath("$.bottomCountryMatches.length()").value(3))
                .andExpect(jsonPath("$.topPersonalityMatch.category").isNotEmpty())
                .andExpect(jsonPath("$.dimensionMatches.length()").value(3))
                .andExpect(jsonPath("$.dimensionMatches[0].dimension").value("political"))
                .andExpect(jsonPath("$.countryDimensionMatches.length()").value(3))
                .andExpect(jsonPath("$.countryDimensionMatches[0].dimension").value("political"))
                .andExpect(jsonPath("$.bottomPersonalityMatches.length()").value(3))
                .andExpect(jsonPath("$.mostUnusualAxis.axisId").isNotEmpty())
                .andExpect(jsonPath("$.mostUnusualAxis.label").isNotEmpty())
                .andExpect(jsonPath("$.mostUnusualAxis.abovePole").isNotEmpty())
                .andExpect(jsonPath("$.mostCommonAxis.axisId").isNotEmpty())
                .andExpect(jsonPath("$.topPartyMatch.historical").value(false))
                .andExpect(jsonPath("$.topPartyMatches.length()").value(3))
                .andExpect(jsonPath("$.topPartyMatches[0].partyId").isNotEmpty())
                .andExpect(jsonPath("$.topPartyMatches[0].countryName").isNotEmpty())
                .andExpect(jsonPath("$.topPartyMatches[0].countryFlagPath").isNotEmpty())
                .andExpect(jsonPath("$.topPartyMatches[0].logoPath").isNotEmpty())
                .andExpect(jsonPath("$.topHistoricalPartyMatch.historical").value(true))
                .andExpect(jsonPath("$.partyDimensionMatches.length()").value(3))
                .andExpect(jsonPath("$.partyDimensionMatches[0].dimension").value("political"))
                .andExpect(jsonPath("$.partyDimensionMatches[0].match.partyId").isNotEmpty())
                .andExpect(jsonPath("$.bottomPartyMatches.length()").value(3));
    }

    @Test
    void englishResultCarriesEveryNewSection() throws Exception {
        mockMvc.perform(get("/api/results/by-axes").param("v", VETOR).param("lang", "en"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.dimensionMatches.length()").value(3))
                .andExpect(jsonPath("$.dimensionMatches[0].dimension").value("political"))
                .andExpect(jsonPath("$.topHistoricalCountryMatch.historical").value(true))
                .andExpect(jsonPath("$.topPartyMatches.length()").value(3))
                .andExpect(jsonPath("$.topPartyMatches[0].category").isNotEmpty());
    }

    @Test
    void freeResultDoesNotCarryTheAreaMatchesOfTheFullReport() throws Exception {
        for (String lang : new String[] {"pt", "en"}) {
            mockMvc.perform(get("/api/results/by-axes").param("v", VETOR).param("lang", lang))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.categoryBestMatches").doesNotExist())
                    .andExpect(jsonPath("$.timeline").doesNotExist());
        }
    }
}
