import { LANG, t } from '../i18n';
import type { PersonalityMatch, QuizPayload, QuizResult } from '../types/quiz';
import { resolveCountryFlagSrc } from './countryFlags';
import { personalityInitials, resolvePersonalityImageSrc } from './personalityImage';
import { resolveIdeologyColor } from './ideologyColors';
import { FILLED_POLE_ICONS } from '../data/filledPoleIcons';
import { religiousPoleIcon } from '../data/religionIcons';
import { qrModules } from './qrMatrix';
import type { Religion } from './religion';
import { shortResultUrl } from './shortLinks';

/**
 * Cartão de compartilhamento social — formato stories 1080x1920.
 *
 * O fundo é a cor base da categoria de espectro do top match; os destaques
 * usam o pastel da mesma categoria. Ver
 * docs/nova-identidade/12axes-identidade-visual.md §11.
 */
export const SHARE_WIDTH = 1080;
export const SHARE_HEIGHT = 1920;

export const SHARE_FONT_DISPLAY = '"Sora"';
export const SHARE_FONT_BODY = '"Poppins"';
const SVG_NS = 'http://www.w3.org/2000/svg';

export const SHARE_COLORS = {
  papel: '#F4F1E8',
  tinta: '#101010'
};

type Style = Partial<CSSStyleDeclaration>;

/**
 * Cores do cabeçalho, da identidade e do rodapé. O padrão é o do cartão escuro (texto em papel sobre a cor da ideologia); os cartões
 * claros (papel com texto escuro) passam as suas. Tudo opcional: o que faltar usa o padrão.
 */
export interface ShareTheme {
  /** O texto principal (a marca, o título e o site). */
  ink?: string;
  /** A etiqueta do canto do cabeçalho. */
  label?: string;
  /** A linha do cabeçalho. */
  rule?: string;
  /** A frase do rodapé. */
  cta?: string;
  /** A linha em cima do rodapé. */
  footerRule?: string;
  /** Os módulos do QR code. */
  qr?: string;
}
export type PoleSide = 'left' | 'right';

export function el(tag: string, style: Style, text?: string): HTMLElement {
  const node = document.createElement(tag);
  node.style.boxSizing = 'border-box';
  Object.assign(node.style, style);
  if (text != null) {
    node.textContent = text;
  }
  return node;
}

export function clamp(value: number): number {
  return Math.max(0, Math.min(100, value));
}

function hexToRgb(hex: string): [number, number, number] {
  let h = hex.replace('#', '');
  if (h.length === 3) {
    h = h.split('').map((c) => c + c).join('');
  }
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

/** Mistura `a` e `b` com `ratioA` peso de `a` (equivalente a color-mix). */
export function mixHex(a: string, b: string, ratioA: number): string {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  const r = Math.round(ar * ratioA + br * (1 - ratioA));
  const g = Math.round(ag * ratioA + bg * (1 - ratioA));
  const bl = Math.round(ab * ratioA + bb * (1 - ratioA));
  return `rgb(${r}, ${g}, ${bl})`;
}

export function rgba(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function readableInk(hex: string): string {
  const [r, g, b] = hexToRgb(hex);
  const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return luminance > 0.48 ? SHARE_COLORS.tinta : SHARE_COLORS.papel;
}

function svgEl(tag: string, attrs: Record<string, string | number>): SVGElement {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attrs)) {
    node.setAttribute(key, String(value));
  }
  return node;
}

const sharePoleIconPaths: Record<string, Record<PoleSide, string[]>> = {
  estrutura: {
    left: ['M4 10h16', 'M6 10v8', 'M10 10v8', 'M14 10v8', 'M18 10v8', 'M3 18h18', 'm12 4 8 4H4l8-4Z'],
    right: ['M6 8h12v12H6z', 'M9 8V5h6v3', 'M9 12h6', 'M9 16h6']
  },
  representacao: {
    left: ['M8 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z', 'M16 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z', 'M3 20a5 5 0 0 1 10 0', 'M11 20a5 5 0 0 1 10 0'],
    right: ['m4 9 4 3 4-7 4 7 4-3-2 10H6L4 9Z', 'M8 19h8']
  },
  poder: {
    left: ['M12 3 5 6v5c0 4.2 2.7 7.9 7 10 4.3-2.1 7-5.8 7-10V6l-7-3Z', 'm9 12 2 2 4-5'],
    right: ['M12 3v18', 'M6 9h12', 'M8 21h8', 'M5 13c1.5 2 4.5 2 6 0', 'M13 13c1.5 2 4.5 2 6 0']
  },
  imigracao: {
    left: ['M7 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z', 'M2 19a5 5 0 0 1 10 0', 'M15 5h5', 'M15 10h5', 'M15 15h5'],
    right: ['M8 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z', 'M3 20a5 5 0 0 1 10 0', 'M14 8h6', 'm17 5 3 3-3 3', 'M15 16h6', 'm18 13 3 3-3 3']
  },
  diplomacia: {
    left: ['M5 20V4', 'M5 5h11l-2 4 2 4H5'],
    right: ['M6 19c6-2 10-6 12-13', 'M7 8c3 1 5 3 6 6', 'M5 13c4 0 7 1 10 4', 'M18 6c-3-1-6-1-9 1']
  },
  intervencao: {
    left: ['M7 12h10', 'm10 8-4 4 4 4', 'M18 5v14'],
    right: ['M6 20V4', 'M6 5h11l-2 4 2 4H6', 'M4 20h8']
  },
  economia: {
    left: ['M5 11h14', 'M7 11v8', 'M17 11v8', 'M12 5v14', 'M4 19h16'],
    right: ['M12 3v18', 'M17 7.5C16 5.8 14.3 5 12 5 9.2 5 7.5 6.3 7.5 8.5S9 12 12 12s4.5 1.2 4.5 3.5S14.8 19 12 19c-2.3 0-4-.8-5-2.5']
  },
  controle: {
    left: ['M4 7h16', 'M4 12h16', 'M4 17h16', 'M9 5v4', 'M15 10v4', 'M11 15v4'],
    right: ['M12 3v18', 'M17 7.5C16 5.8 14.3 5 12 5 9.2 5 7.5 6.3 7.5 8.5S9 12 12 12s4.5 1.2 4.5 3.5S14.8 19 12 19c-2.3 0-4-.8-5-2.5']
  },
  comercio: {
    left: ['M12 3 5 6v5c0 4.2 2.7 7.9 7 10 4.3-2.1 7-5.8 7-10V6l-7-3Z', 'm9 12 2 2 4-5'],
    right: ['M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z', 'M3 12h18', 'M12 3c2.4 2.5 3.6 5.5 3.6 9S14.4 18.5 12 21', 'M12 3c-2.4 2.5-3.6 5.5-3.6 9s1.2 6.5 3.6 9']
  },
  religiao: {
    left: ['M12 4v16', 'M4 12h16', 'M6 18 18 6'],
    right: ['M12 3v18', 'M7 8h10', 'M6 20h12']
  },
  moral: {
    left: ['M20 8c0 6-8 11-8 11S4 14 4 8a4 4 0 0 1 7-2.7A4 4 0 0 1 20 8Z'],
    right: ['M7 4h10', 'M8 20h8', 'M9 4c0 5 6 5 6 10 0 2-1.3 4-3 6-1.7-2-3-4-3-6 0-5 6-5 6-10']
  },
  tecnologia: {
    left: ['M8 8h8v8H8z', 'M4 10h4', 'M4 14h4', 'M16 10h4', 'M16 14h4', 'M10 4v4', 'M14 4v4', 'M10 16v4', 'M14 16v4'],
    right: ['M5 19c8 0 13-5 14-14-7 1-13 5-14 14Z', 'M5 19c4-5 8-8 14-14']
  }
};

export function buildShareCard(
  result: QuizResult,
  quiz: QuizPayload,
  religion: Religion | null = null
): { stage: HTMLDivElement; target: HTMLDivElement; backgroundColor: string } {
  const color = resolveIdeologyColor(result.topMatch.category);
  const stage = el('div', {
    position: 'fixed',
    top: '0',
    left: `-${SHARE_WIDTH + 200}px`,
    width: `${SHARE_WIDTH}px`,
    height: `${SHARE_HEIGHT}px`,
    pointerEvents: 'none',
    zIndex: '-1'
  }) as HTMLDivElement;

  const target = el('div', {
    position: 'relative',
    width: `${SHARE_WIDTH}px`,
    height: `${SHARE_HEIGHT}px`,
    padding: '64px',
    boxSizing: 'border-box',
    // Fundo transparente: o fundo e as fotos são desenhados direto no canvas
    // (ver renderSharePng), o html-to-image só renderiza texto e caixas.
    background: 'transparent',
    fontFamily: SHARE_FONT_BODY,
    color: SHARE_COLORS.papel,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden'
  }) as HTMLDivElement;

  const content = el('div', {
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    flex: '1 1 auto',
    minHeight: '0',
    gap: '24px'
  });

  content.append(
    buildShareHeader(),
    buildShareIdentity(result, color.bg),
    buildShareTwoColumns(result, quiz, color, religion),
    buildShareLists(result, color),
    buildShareFooter(
      t.shareFooterCta,
      // Inteiros (meio ponto a menos de precisão): link mais curto, QR 33x33 e não 37x37.
      shortResultUrl(
        result.axes.map((axis) => Math.round(axis.leftPercent)),
        religion,
        LANG
      )
    )
  );

  target.append(content);
  target.dataset.shareBase = color.base;
  target.dataset.shareCircle = mixHex(color.base, SHARE_COLORS.papel, 0.9);
  stage.append(target);
  return { stage, target, backgroundColor: color.base };
}

export function buildShareHeader(label: string = t.shareResultLabel, theme: ShareTheme = {}): HTMLElement {
  const P = theme.ink ?? SHARE_COLORS.papel;
  const header = el('div', {
    display: 'flex',
    alignItems: 'center',
    gap: '28px'
  });
  header.append(
    el('div', {
      fontFamily: SHARE_FONT_DISPLAY,
      fontWeight: '800',
      fontSize: '58px',
      letterSpacing: '-0.03em',
      color: P,
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: '9px'
    }),
    el('div', { flex: '1 1 auto', height: '3px', background: theme.rule ?? rgba(P, 0.35) }),
    el('div', {
      fontFamily: SHARE_FONT_BODY,
      fontWeight: '600',
      fontSize: '30px',
      letterSpacing: '0.16em',
      textTransform: 'uppercase',
      whiteSpace: 'nowrap',
      color: theme.label ?? rgba(P, 0.82)
    }, label)
  );
  const brand = header.firstChild as HTMLElement;
  brand.append(
    el('span', {}, '12'),
    el('span', { fontFamily: SHARE_FONT_BODY, fontWeight: '400' }, 'axes')
  );
  return header;
}

export function buildShareIdentity(result: QuizResult, bgColor: string, ink: string = SHARE_COLORS.papel): HTMLElement {
  const P = ink;
  const wrap = el('div', { display: 'flex', flexDirection: 'column', gap: '0', marginTop: '18px' });
  wrap.append(
    el('div', {
      fontFamily: SHARE_FONT_BODY,
      fontWeight: '600',
      fontSize: '34px',
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      color: bgColor
    }, result.topMatch.category),
    el('div', {
      fontFamily: SHARE_FONT_DISPLAY,
      fontWeight: '600',
      fontSize: `${fitTitleFontSize(result.topMatch.name)}px`,
      lineHeight: '1.05',
      letterSpacing: '-0.02em',
      // Uma linha só: a faixa do título é fixa e uma segunda linha sobrepõe o retrato e os eixos.
      whiteSpace: 'nowrap',
      // Altura fixa (a do tamanho máximo): título menor não puxa o resto do card para cima.
      height: `${Math.round(TITLE_MAX_PX * 1.05)}px`,
      display: 'flex',
      alignItems: 'center',
      color: P,
      marginTop: '-8px'
    }, result.topMatch.name)
  );
  return wrap;
}

const TITLE_MAX_PX = 76;
const TITLE_MIN_PX = 40;
// Largura útil do título (card menos o padding de 64px de cada lado) com folga: a fonte do
// aparelho pode renderizar um pouco mais larga que a medida aqui e o título não pode quebrar.
const TITLE_MAX_WIDTH = (SHARE_WIDTH - 128) * 0.88;

/** Maior tamanho (até 76px) em que o nome da ideologia cabe numa linha. */
function fitTitleFontSize(text: string): number {
  const ctx = document.createElement('canvas').getContext('2d');
  if (!ctx) {
    return TITLE_MAX_PX;
  }
  ctx.font = `600 ${TITLE_MAX_PX}px ${SHARE_FONT_DISPLAY}, sans-serif`;
  const width = ctx.measureText(text).width;
  if (!width || width <= TITLE_MAX_WIDTH) {
    return TITLE_MAX_PX;
  }
  return Math.max(TITLE_MIN_PX, Math.floor((TITLE_MAX_PX * TITLE_MAX_WIDTH) / width));
}

function buildShareTwoColumns(
  result: QuizResult,
  quiz: QuizPayload,
  color: { base: string; bg: string },
  religion: Religion | null
): HTMLElement {
  const row = el('div', {
    display: 'flex',
    gap: '24px',
    flex: `0 0 ${COLUMNS_HEIGHT}px`,
    height: `${COLUMNS_HEIGHT}px`,
    minHeight: `${COLUMNS_HEIGHT}px`,
    marginTop: '8px'
  });
  row.append(
    buildSharePersonalityPortrait(result.topPersonalityMatch, color),
    buildShareAxesColumn(result, quiz, color, religion)
  );
  return row;
}

function buildSharePersonalityPortrait(
  person: PersonalityMatch,
  color: { base: string; bg: string }
): HTMLElement {
  const P = SHARE_COLORS.papel;
  const frame = el('div', {
    position: 'relative',
    flex: '0 0 390px',
    height: `${COLUMNS_HEIGHT}px`,
    borderRadius: '36px',
    overflow: 'hidden'
  });

  // A foto, o véu e o degradê são compostos no canvas, embaixo deste texto.
  frame.dataset.shareImage = 'portrait';
  frame.dataset.shareSrc = resolvePersonalityImageSrc(person.imagePath);

  const text = el('div', {
    position: 'absolute',
    left: '32px',
    right: '32px',
    bottom: '32px',
    display: 'flex',
    flexDirection: 'column',
    gap: '4px'
  });
  const pct = clamp(person.compatibility);
  text.append(
    el('div', {
      fontFamily: SHARE_FONT_DISPLAY,
      fontWeight: '700',
      fontSize: '84px',
      lineHeight: '1',
      letterSpacing: '-3px',
      color: color.bg
    }, `${Math.round(pct)}%`),
    el('div', {
      fontFamily: SHARE_FONT_BODY,
      fontWeight: '600',
      fontSize: '26px',
      letterSpacing: '4px',
      textTransform: 'uppercase',
      color: color.bg
    }, t.shareMostCompatible),
    el('div', {
      fontFamily: SHARE_FONT_DISPLAY,
      fontWeight: '600',
      fontSize: '48px',
      lineHeight: '1.15',
      letterSpacing: '-1px',
      color: P,
      marginTop: '6px'
    }, person.name),
    el('div', {
      fontFamily: SHARE_FONT_BODY,
      fontSize: '30px',
      color: rgba(P, 0.82)
    }, person.role)
  );
  frame.append(text);

  return frame;
}

function buildShareAxesColumn(
  result: QuizResult,
  quiz: QuizPayload,
  color: { base: string; bg: string },
  religion: Religion | null
): HTMLElement {
  const P = SHARE_COLORS.papel;
  const col = el('div', {
    flex: '1 1 auto',
    minWidth: '0',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    padding: '30px 30px 26px',
    borderRadius: '36px',
    background: 'rgba(0, 0, 0, 0.22)',
    border: `2px solid ${rgba(P, 0.14)}`
  });
  col.append(el('div', {
    fontFamily: SHARE_FONT_BODY,
    fontWeight: '600',
    fontSize: '26px',
    letterSpacing: '4px',
    textTransform: 'uppercase',
    color: color.bg
  }, t.shareYourAxes));

  const list = el('div', {
    display: 'flex',
    flexDirection: 'column',
    gap: '0',
    flex: '1 1 auto',
    justifyContent: 'space-between'
  });
  const axesById = new Map(quiz.axes.map((axis) => [axis.id, axis]));
  result.axes.forEach((axis) => list.append(buildShareAxisLine(axis, axesById.get(axis.axisId), color, religion)));
  col.append(list);
  return col;
}

function buildShareAxisLine(
  axis: QuizResult['axes'][number],
  definition: QuizPayload['axes'][number] | undefined,
  color: { base: string; bg: string },
  religion: Religion | null
): HTMLElement {
  const P = SHARE_COLORS.papel;
  const isBalanced = axis.intensity === 'Equilibrado';
  const leaningRight = axis.dominantPole === axis.rightPole;
  const winningPole = isBalanced ? axis.rightPole : leaningRight ? axis.rightPole : axis.leftPole;
  const winningPct = isBalanced ? 50 : leaningRight ? axis.rightPercent : axis.leftPercent;
  // Mesmo lado do rótulo: equilibrado mostra o polo direito, então o ícone também.
  const side: PoleSide = isBalanced || leaningRight ? 'right' : 'left';
  const accent = isBalanced
    ? color.bg
    : leaningRight
      ? definition?.rightColor ?? color.bg
      : definition?.leftColor ?? color.bg;

  const row = el('div', {
    display: 'flex',
    alignItems: 'center',
    gap: '13px',
    height: '58px'
  });

  const icon = el('span', {
    flex: '0 0 auto',
    width: '46px',
    height: '46px',
    borderRadius: '13px',
    display: 'grid',
    placeItems: 'center',
    color: readableInk(accent),
    background: accent
  });
  icon.append(buildPoleGlyph(axis.axisId, side, religion));

  const mini = el('span', {
    flex: '0 0 76px',
    width: '76px',
    height: '10px',
    borderRadius: '10px',
    overflow: 'hidden',
    background: rgba(P, 0.16)
  });
  mini.append(el('i', {
    display: 'block',
    width: `${clamp(winningPct)}%`,
    height: '100%',
    borderRadius: '10px',
    background: accent
  }));

  row.append(
    icon,
    el('span', {
      flex: '1 1 auto',
      minWidth: '0',
      fontFamily: SHARE_FONT_BODY,
      fontWeight: '500',
      fontSize: '28px',
      color: rgba(P, 0.92),
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }, winningPole),
    mini,
    el('span', {
      flex: '0 0 70px',
      width: '70px',
      textAlign: 'right',
      fontFamily: SHARE_FONT_DISPLAY,
      fontWeight: '700',
      fontSize: '32px',
      color: accent
    }, `${Math.round(winningPct)}%`)
  );

  return row;
}

export function buildPoleGlyph(axisId: string, side: PoleSide, religion: Religion | null): SVGElement {
  // Polo "Religioso" mostra a religião escolhida; sem escolha, a cruz.
  const filled = (axisId === 'religiao' && side === 'right' && religiousPoleIcon(religion)) || FILLED_POLE_ICONS[axisId]?.[side];
  if (filled) {
    const filledSvg = svgEl('svg', { viewBox: filled.viewBox, width: 26, height: 26, fill: 'currentColor', stroke: 'none' });
    filled.paths.forEach((d) => filledSvg.append(svgEl('path', { d, 'fill-rule': filled.fillRule ?? 'evenodd', 'clip-rule': filled.fillRule ?? 'evenodd' })));
    return filledSvg;
  }
  const svg = svgEl('svg', {
    viewBox: '0 0 24 24',
    width: 26,
    height: 26,
    fill: 'none',
    stroke: 'currentColor',
    'stroke-width': 2.2,
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round'
  });
  const paths = sharePoleIconPaths[axisId]?.[side] ?? sharePoleIconPaths.estrutura[side];
  paths.forEach((path) => svg.append(svgEl('path', { d: path })));
  return svg;
}

function buildShareLists(
  result: QuizResult,
  color: { base: string; bg: string }
): HTMLElement {
  const row = el('div', {
    display: 'flex',
    gap: '24px'
  });
  row.append(
    buildShareListBox(
      t.shareOtherPersonalities,
      result.personalityMatches.slice(1, 4).map((person) => ({
        label: person.name,
        pct: person.compatibility,
        avatar: resolvePersonalityImageSrc(person.imagePath),
        alt: person.name,
        initials: personalityInitials(person.name)
      })),
      color,
      'avatar'
    ),
    buildShareListBox(
      t.shareNearbyCountries,
      (result.topCountryMatches ?? []).slice(0, 3).map((country) => ({
        label: country.name,
        pct: country.compatibility,
        avatar: resolveCountryFlagSrc(country.flagPath),
        alt: country.name,
        initials: country.name.slice(0, 2).toUpperCase()
      })),
      color,
      'flag'
    )
  );
  return row;
}

interface ShareListItem {
  label: string;
  pct: number;
  avatar: string;
  alt: string;
  initials: string;
}

function buildShareListBox(
  title: string,
  items: ShareListItem[],
  color: { base: string; bg: string },
  kind: 'avatar' | 'flag'
): HTMLElement {
  const P = SHARE_COLORS.papel;
  const box = el('div', {
    flex: '1 1 0',
    minWidth: '0',
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    padding: '28px 30px',
    borderRadius: '36px',
    background: 'rgba(0, 0, 0, 0.22)',
    border: `2px solid ${rgba(P, 0.14)}`
  });
  box.append(el('div', {
    fontFamily: SHARE_FONT_BODY,
    fontWeight: '600',
    fontSize: '26px',
    letterSpacing: '4px',
    textTransform: 'uppercase',
    color: color.bg
  }, title));

  items.forEach((item) => {
    const line = el('div', { display: 'flex', alignItems: 'center', gap: '18px' });
    const avatarFrame = el('div', {
      flex: '0 0 auto',
      width: '76px',
      height: kind === 'avatar' ? '76px' : '52px',
      borderRadius: kind === 'avatar' ? '50%' : '10px',
      overflow: 'hidden',
      background: mixHex(color.base, '#000000', 0.6),
      display: 'grid',
      placeItems: 'center',
      fontFamily: SHARE_FONT_DISPLAY,
      fontWeight: '700',
      fontSize: '22px',
      color: rgba(SHARE_COLORS.papel, 0.7)
    }, item.initials);
    // A imagem é desenhada no canvas por cima destas iniciais (que só ficam
    // visíveis se a imagem não carregar).
    avatarFrame.dataset.shareImage = kind;
    avatarFrame.dataset.shareSrc = item.avatar;

    line.append(
      avatarFrame,
      el('span', {
        flex: '1 1 auto',
        minWidth: '0',
        fontFamily: SHARE_FONT_BODY,
        fontWeight: '500',
        fontSize: kind === 'flag' && item.label.length > 22 ? '25px' : '30px',
        lineHeight: kind === 'flag' ? '1.08' : '1.2',
        color: rgba(P, 0.92),
        whiteSpace: 'normal',
        wordBreak: 'normal',
        overflowWrap: 'break-word'
      }, item.label),
      el('span', {
        flex: '0 0 auto',
        fontFamily: SHARE_FONT_DISPLAY,
        fontWeight: '700',
        fontSize: '30px',
        color: color.bg
      }, `${Math.round(clamp(item.pct))}%`)
    );
    box.append(line);
  });

  return box;
}

/** Lado do QR code no rodapé, em px (o quadrado branco inteiro, com a margem de silêncio). */
export const SHARE_QR_SIZE = 150;

// O rodapé com QR é mais alto que o de uma linha (26 + QR contra ~70): as duas colunas do meio cedem essa diferença.
const COLUMNS_HEIGHT = 920 - (26 + SHARE_QR_SIZE - 70);

/**
 * Rodapé do cartão: a frase em cima e o site embaixo, à esquerda, e o QR code (link do resultado) no canto direito.
 * Sem `qrUrl` volta ao rodapé simples de uma linha. O QR é desenhado no canvas (ver drawQr); aqui fica só a caixa.
 */
export function buildShareFooter(cta: string = t.shareFooterCta, qrUrl?: string, qrSize: number = SHARE_QR_SIZE, theme: ShareTheme = {}): HTMLElement {
  const P = theme.ink ?? SHARE_COLORS.papel;
  const footer = el('div', {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: qrUrl ? '26px' : '30px',
    borderTop: `2px solid ${theme.footerRule ?? rgba(P, 0.25)}`
  });
  const ctaText = el('span', {
    fontFamily: SHARE_FONT_BODY,
    fontWeight: '600',
    fontSize: '30px',
    letterSpacing: '0.16em',
    textTransform: 'uppercase',
    lineHeight: '1',
    color: theme.cta ?? rgba(P, 0.9)
  }, cta);
  const urlText = el('span', {
    fontFamily: SHARE_FONT_DISPLAY,
    fontWeight: '700',
    fontSize: '30px',
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    lineHeight: '1',
    color: P
  }, t.shareFooterUrl);
  // Seta de "abrir" ao lado do endereço.
  const arrow = svgEl('svg', { viewBox: '0 0 24 24', width: 36, height: 36, fill: 'currentColor', 'aria-hidden': 'true' });
  arrow.append(svgEl('path', { d: 'M6.4 18L5 16.6L14.6 7H6V5h12v12h-2V8.4z' }));
  arrow.style.display = 'block';
  arrow.style.flex = 'none';
  arrow.style.color = P;
  const urlRow = el('span', { display: 'inline-flex', alignItems: 'center', gap: '8px' });
  urlRow.append(urlText, arrow);

  if (!qrUrl) {
    footer.append(ctaText, urlRow);
    return footer;
  }

  // A caixa do QR tem exatamente o tamanho dos seus módulos (inteiros de pixels), para o texto centralizar com ele de verdade.
  const modules = qrModules(qrUrl, 'L').length;
  const side = Math.floor(qrSize / modules) * modules;
  const qr = el('div', { width: `${side}px`, height: `${side}px`, flex: 'none' });
  qr.dataset.shareImage = 'qr';
  qr.dataset.shareSrc = qrUrl;
  // A cor dos módulos (o papel, nos cartões escuros).
  if (theme.qr) qr.dataset.shareTint = theme.qr;
  const text = el('div', {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'center',
    gap: '26px'
  });
  text.append(ctaText, urlRow);
  footer.append(text, qr);
  return footer;
}


/*
 * Exportação em camadas.
 *
 * O html-to-image desenha o DOM dentro de um SVG <foreignObject>. No Safari
 * (e em alguns Androids) esse SVG pode "terminar de carregar" antes das
 * imagens internas serem decodificadas, e o PNG sai sem as fotos — de forma
 * intermitente. Por isso as imagens nunca passam pelo html-to-image: ele só
 * renderiza texto, caixas e ícones sobre fundo transparente, e o resto é
 * desenhado aqui no canvas, esperando cada imagem carregar de verdade.
 *
 * Ordem das camadas: fundo → retrato composto → DOM → avatares e bandeiras
 * (estes por último porque ficam dentro de caixas translúcidas).
 */

type ToPng = (node: HTMLElement, options?: Record<string, unknown>) => Promise<string>;
type ShareImageKind =
  | 'portrait' | 'avatar' | 'flag' | 'flagfit' | 'flagcover' | 'flaground' | 'logo' | 'logosmall' | 'logoround' | 'badge' | 'badgesmall' | 'mosaic' | 'photo' | 'tint' | 'qr';

interface ShareImageSlot {
  kind: ShareImageKind;
  src: string;
  rect: CanvasRect;
  /** Em 'qr' o `src` é o texto codificado (o link), não uma imagem. */
  /** Só em 'tint': a cor do cartão (a da ideologia), que vira um degradê claro → escuro. */
  tint?: string;
}

type CanvasRect = { x: number; y: number; width: number; height: number };

const IMAGE_TIMEOUT_MS = 8000;

export async function renderSharePng(target: HTMLElement, toPng: ToPng): Promise<string> {
  const slots = collectImageSlots(target);
  // Carrega as imagens em paralelo com o render do DOM.
  const imagesPromise = Promise.all(
    slots.map((slot) => (slot.kind === 'tint' || slot.kind === 'qr' || slot.kind === 'mosaic' ? Promise.resolve(null) : loadImage(slot.src).catch(() => null)))
  );
  // O mosaico da época mais compatível tem 4 imagens: o `src` dele é uma lista JSON de { src, fit }.
  const mosaicsPromise = Promise.all(slots.map((slot) => (slot.kind === 'mosaic' ? loadMosaic(slot.src) : Promise.resolve(null))));

  const domDataUrl = await toPng(target, {
    width: SHARE_WIDTH,
    height: SHARE_HEIGHT,
    pixelRatio: 1,
    cacheBust: false,
    skipFonts: false
  });
  const [domLayer, images, mosaics] = await Promise.all([loadImage(domDataUrl), imagesPromise, mosaicsPromise]);

  const canvas = document.createElement('canvas');
  canvas.width = SHARE_WIDTH;
  canvas.height = SHARE_HEIGHT;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas indisponível');
  }

  const base = target.dataset.shareBase ?? '#101010';
  drawBackground(ctx, base, target.dataset.shareCircle ?? base, target.dataset.shareGradient);

  slots.forEach((slot, index) => {
    if (slot.kind === 'portrait') {
      drawPortrait(ctx, images[index], slot.rect, base);
    } else if (slot.kind === 'tint') {
      // Fica embaixo do DOM: o texto do cartão é desenhado por cima do degradê.
      drawTintCard(ctx, slot.rect, slot.tint ?? base);
    }
  });

  ctx.drawImage(domLayer, 0, 0, SHARE_WIDTH, SHARE_HEIGHT);

  slots.forEach((slot, index) => {
    if (slot.kind === 'qr') {
      drawQr(ctx, slot.src, slot.rect, slot.tint ?? SHARE_COLORS.papel);
      return;
    }
    if (slot.kind === 'mosaic') {
      const mosaic = mosaics[index];
      if (mosaic) drawMosaic(ctx, mosaic, slot.rect);
      return;
    }
    const image = images[index];
    if (!image || slot.kind === 'portrait' || slot.kind === 'tint') {
      return;
    }
    ctx.save();
    if (slot.kind === 'photo') {
      roundedRectPath(ctx, slot.rect, 22);
      ctx.clip();
      drawCover(ctx, image, slot.rect, 0.2);
    } else if (slot.kind === 'flagfit') {
      drawFlagFit(ctx, image, slot.rect);
    } else if (slot.kind === 'flagcover') {
      drawFlagCover(ctx, image, slot.rect);
    } else if (slot.kind === 'logo') {
      drawLogo(ctx, image, slot.rect, 36, 18, true);
    } else if (slot.kind === 'logosmall') {
      drawLogo(ctx, image, slot.rect, 20, 8, false);
    } else if (slot.kind === 'badge') {
      drawBadge(ctx, image, slot.rect, 10, 4, true);
    } else if (slot.kind === 'badgesmall') {
      drawBadge(ctx, image, slot.rect, 6, 2, false);
    } else if (slot.kind === 'flaground') {
      // Bandeira num círculo: cortada do centro, sem o ajuste para o alto que os retratos têm.
      ctx.beginPath();
      ctx.ellipse(slot.rect.x + slot.rect.width / 2, slot.rect.y + slot.rect.height / 2, slot.rect.width / 2, slot.rect.height / 2, 0, 0, Math.PI * 2);
      ctx.clip();
      drawCover(ctx, image, slot.rect, 0.5);
    } else if (slot.kind === 'logoround') {
      drawLogoRound(ctx, image, slot.rect);
    } else if (slot.kind === 'avatar') {
      ctx.beginPath();
      ctx.ellipse(
        slot.rect.x + slot.rect.width / 2,
        slot.rect.y + slot.rect.height / 2,
        slot.rect.width / 2,
        slot.rect.height / 2,
        0,
        0,
        Math.PI * 2
      );
      ctx.clip();
      drawCover(ctx, image, slot.rect, 0.2);
    } else {
      roundedRectPath(ctx, slot.rect, 10);
      ctx.clip();
      drawCover(ctx, image, slot.rect, 0.5);
    }
    ctx.restore();
  });

  return canvas.toDataURL('image/png');
}

// QR code: módulos claros (a cor do papel do cartão) direto sobre o fundo, sem quadro, desenhados no canvas
// (nítidos e sem passar pelo html-to-image). O fundo escuro do cartão faz a margem de silêncio; o leitor lê o código invertido.
function drawQr(ctx: CanvasRenderingContext2D, text: string, rect: CanvasRect, color: string) {
  // Nível L: menos redundância, menos módulos e cada um maior; o cartão é uma imagem limpa, sem risco de sujeira.
  const modules = qrModules(text, 'L');
  const count = modules.length;
  const cell = Math.floor(rect.width / count);
  // A caixa já tem o tamanho exato dos módulos; centraliza por segurança se vier maior.
  const offset = rect.x + (rect.width - cell * count) / 2;
  const top = rect.y + (rect.height - cell * count) / 2;
  ctx.save();
  ctx.fillStyle = color;
  modules.forEach((row, y) =>
    row.forEach((dark, x) => {
      if (dark) {
        ctx.fillRect(offset + x * cell, top + y * cell, cell, cell);
      }
    })
  );
  ctx.restore();
}

function collectImageSlots(root: HTMLElement): ShareImageSlot[] {
  const rootRect = root.getBoundingClientRect();
  return Array.from(root.querySelectorAll<HTMLElement>('[data-share-image]'))
    .map((frame): ShareImageSlot | null => {
      const kind = frame.dataset.shareImage as ShareImageKind;
      const src = frame.dataset.shareSrc ?? '';
      const rect = frame.getBoundingClientRect();
      if ((!src && kind !== 'tint') || rect.width <= 0 || rect.height <= 0) {
        return null;
      }
      return {
        kind,
        src,
        tint: frame.dataset.shareTint,
        rect: {
          x: rect.left - rootRect.left,
          y: rect.top - rootRect.top,
          width: rect.width,
          height: rect.height
        }
      };
    })
    .filter((slot): slot is ShareImageSlot => slot !== null);
}

// Carrega via fetch → blob → objectURL para não depender de cabeçalhos CORS e
// garante que a imagem está decodificada antes de ir para o canvas.
async function loadImage(src: string): Promise<HTMLImageElement> {
  let objectUrl: string | null = null;
  let url = src;
  if (!src.startsWith('data:')) {
    const response = await withTimeout(
      fetch(new URL(src, window.location.href).href, { cache: 'force-cache', credentials: 'same-origin' }),
      IMAGE_TIMEOUT_MS
    );
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    objectUrl = URL.createObjectURL(await response.blob());
    url = objectUrl;
  }
  try {
    const image = new Image();
    await withTimeout(
      new Promise<void>((resolve, reject) => {
        image.onload = () => resolve();
        image.onerror = () => reject(new Error('Could not decode image'));
        image.src = url;
      }),
      IMAGE_TIMEOUT_MS
    );
    if (typeof image.decode === 'function') {
      await image.decode().catch(() => undefined);
    }
    return image;
  } finally {
    if (objectUrl) {
      const toRevoke = objectUrl;
      // Revoga depois do desenho: alguns Safaris ainda leem o blob no drawImage.
      window.setTimeout(() => URL.revokeObjectURL(toRevoke), 30000);
    }
  }
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = window.setTimeout(() => reject(new Error('timeout')), ms);
    promise.then(
      (value) => {
        window.clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        window.clearTimeout(timer);
        reject(error);
      }
    );
  });
}

// Fundo da cor da categoria com o círculo claro no canto superior direito.
function drawBackground(ctx: CanvasRenderingContext2D, base: string, circle: string, gradient?: string) {
  if (gradient) {
    // "cor1;cor2[;...]": degradê a 160° (cartão de comparação: de uma cor para a da outra pessoa) e círculo translúcido
    // no canto, como no desenho. Em CSS, 160° vai quase para baixo e um pouco para a direita; a linha do degradê
    // atravessa o centro com o comprimento que cobre o cartão inteiro.
    const stops = gradient.split(';');
    const angle = (160 * Math.PI) / 180;
    const dx = Math.sin(angle);
    const dy = -Math.cos(angle);
    const half = (Math.abs(SHARE_WIDTH * dx) + Math.abs(SHARE_HEIGHT * dy)) / 2;
    const cx = SHARE_WIDTH / 2;
    const cy = SHARE_HEIGHT / 2;
    const fill = ctx.createLinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half);
    stops.forEach((stop, index) => fill.addColorStop(stops.length === 1 ? 0 : index / (stops.length - 1), stop));
    ctx.fillStyle = fill;
    ctx.fillRect(0, 0, SHARE_WIDTH, SHARE_HEIGHT);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.07)';
    ctx.beginPath();
    ctx.arc(SHARE_WIDTH - 90, 40, 340, 0, Math.PI * 2);
    ctx.fill();
    return;
  }
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, SHARE_WIDTH, SHARE_HEIGHT);
  ctx.fillStyle = circle;
  ctx.beginPath();
  ctx.arc(SHARE_WIDTH, 0, 400, 0, Math.PI * 2);
  ctx.fill();
}

// Cartão de país da comparação: degradê a 150° da cor da ideologia (clareada em 22%) até a cor cheia aos 70%,
// com cantos de 28px. A bandeira (drawFlagFit) e o texto vêm por cima.
function drawTintCard(ctx: CanvasRenderingContext2D, rect: CanvasRect, tint: string) {
  ctx.save();
  roundedRectPath(ctx, rect, 28);
  ctx.clip();
  const angle = (150 * Math.PI) / 180;
  const dx = Math.sin(angle);
  const dy = -Math.cos(angle);
  const half = (Math.abs(rect.width * dx) + Math.abs(rect.height * dy)) / 2;
  const cx = rect.x + rect.width / 2;
  const cy = rect.y + rect.height / 2;
  const gradient = ctx.createLinearGradient(cx - dx * half, cy - dy * half, cx + dx * half, cy + dy * half);
  gradient.addColorStop(0, mixHex(tint, '#FFFFFF', 0.78));
  gradient.addColorStop(0.7, tint);
  gradient.addColorStop(1, tint);
  ctx.fillStyle = gradient;
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
  ctx.restore();
}

// Bandeira inteira, sem corte nem zoom: cabe na caixa na proporção dela (3:2, 2:1, quadrada...), centralizada,
// com cantos de 16px e sombra.
function drawFlagFit(ctx: CanvasRenderingContext2D, image: HTMLImageElement, rect: CanvasRect) {
  const scale = Math.min(rect.width / image.naturalWidth, rect.height / image.naturalHeight);
  const width = image.naturalWidth * scale;
  const height = image.naturalHeight * scale;
  const fit = { x: rect.x + (rect.width - width) / 2, y: rect.y + (rect.height - height) / 2, width, height };
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
  ctx.shadowBlur = 18;
  ctx.shadowOffsetY = 6;
  roundedRectPath(ctx, fit, 16);
  ctx.fillStyle = '#000000';
  ctx.fill();
  ctx.restore();
  ctx.save();
  roundedRectPath(ctx, fit, 16);
  ctx.clip();
  ctx.drawImage(image, fit.x, fit.y, fit.width, fit.height);
  ctx.restore();
}

// Bandeira cortada para preencher a moldura (3:2, como na página de resultado), com cantos de 16px e a mesma sombra da bandeira
// inteira: bandeiras de proporções diferentes ficam todas do mesmo tamanho.
function drawFlagCover(ctx: CanvasRenderingContext2D, image: HTMLImageElement, rect: CanvasRect) {
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
  ctx.shadowBlur = 18;
  ctx.shadowOffsetY = 6;
  roundedRectPath(ctx, rect, 16);
  ctx.fillStyle = '#000000';
  ctx.fill();
  ctx.restore();
  ctx.save();
  roundedRectPath(ctx, rect, 16);
  ctx.clip();
  drawCover(ctx, image, rect, 0.5);
  ctx.restore();
}

// Logo de partido: caixa branca de cantos arredondados com o logo inteiro (sem corte), dentro de uma margem. A versão grande leva sombra.
function drawLogo(ctx: CanvasRenderingContext2D, image: HTMLImageElement, rect: CanvasRect, radius: number, pad: number, shadow: boolean) {
  ctx.save();
  if (shadow) {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
    ctx.shadowBlur = 18;
    ctx.shadowOffsetY = 6;
  }
  roundedRectPath(ctx, rect, radius);
  ctx.fillStyle = '#FFFFFF';
  ctx.fill();
  ctx.restore();
  const inner = { x: rect.x + pad, y: rect.y + pad, width: rect.width - pad * 2, height: rect.height - pad * 2 };
  const scale = Math.min(inner.width / image.naturalWidth, inner.height / image.naturalHeight);
  const width = image.naturalWidth * scale;
  const height = image.naturalHeight * scale;
  ctx.save();
  roundedRectPath(ctx, rect, radius);
  ctx.clip();
  ctx.drawImage(image, inner.x + (inner.width - width) / 2, inner.y + (inner.height - height) / 2, width, height);
  ctx.restore();
}

// Bandeira do país do partido, em selo: moldura branca de `border` px, bandeira cortada para preencher o resto.
function drawBadge(ctx: CanvasRenderingContext2D, image: HTMLImageElement, rect: CanvasRect, radius: number, border: number, shadow: boolean) {
  ctx.save();
  if (shadow) {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.35)';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetY = 4;
  }
  roundedRectPath(ctx, rect, radius);
  ctx.fillStyle = '#FFFFFF';
  ctx.fill();
  ctx.restore();
  const inner = { x: rect.x + border, y: rect.y + border, width: rect.width - border * 2, height: rect.height - border * 2 };
  ctx.save();
  roundedRectPath(ctx, inner, Math.max(0, radius - border));
  ctx.clip();
  drawCover(ctx, image, inner, 0.5);
  ctx.restore();
}

// Logo de partido num círculo branco, inteiro (sem corte), com uma pequena margem.
function drawLogoRound(ctx: CanvasRenderingContext2D, image: HTMLImageElement, rect: CanvasRect) {
  ctx.beginPath();
  ctx.ellipse(rect.x + rect.width / 2, rect.y + rect.height / 2, rect.width / 2, rect.height / 2, 0, 0, Math.PI * 2);
  ctx.fillStyle = '#FFFFFF';
  ctx.fill();
  ctx.clip();
  const pad = rect.width * 0.14;
  const scale = Math.min((rect.width - pad * 2) / image.naturalWidth, (rect.height - pad * 2) / image.naturalHeight);
  const width = image.naturalWidth * scale;
  const height = image.naturalHeight * scale;
  ctx.drawImage(image, rect.x + (rect.width - width) / 2, rect.y + (rect.height - height) / 2, width, height);
}

interface MosaicCell {
  src: string;
  /** 'cover' preenche a célula (retratos e bandeiras); 'contain' mostra o logo inteiro sobre branco. */
  fit: 'cover' | 'contain';
}

async function loadMosaic(json: string): Promise<{ cell: MosaicCell; image: HTMLImageElement | null }[]> {
  const cells = JSON.parse(json) as MosaicCell[];
  return Promise.all(cells.map(async (cell) => ({ cell, image: await loadImage(cell.src).catch(() => null) })));
}

// Quadrado 2x2 da época mais compatível: até 4 imagens, recortado com cantos de 26px.
function drawMosaic(ctx: CanvasRenderingContext2D, items: { cell: MosaicCell; image: HTMLImageElement | null }[], rect: CanvasRect) {
  ctx.save();
  roundedRectPath(ctx, rect, 26);
  ctx.clip();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
  const width = rect.width / 2;
  const height = rect.height / 2;
  items.slice(0, 4).forEach(({ cell, image }, index) => {
    if (!image) return;
    const slot = { x: rect.x + (index % 2) * width, y: rect.y + Math.floor(index / 2) * height, width, height };
    ctx.save();
    ctx.beginPath();
    ctx.rect(slot.x, slot.y, slot.width, slot.height);
    ctx.clip();
    if (cell.fit === 'contain') {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(slot.x, slot.y, slot.width, slot.height);
      const pad = 10;
      const scale = Math.min((slot.width - pad * 2) / image.naturalWidth, (slot.height - pad * 2) / image.naturalHeight);
      const w = image.naturalWidth * scale;
      const h = image.naturalHeight * scale;
      ctx.drawImage(image, slot.x + (slot.width - w) / 2, slot.y + (slot.height - h) / 2, w, h);
    } else {
      drawCover(ctx, image, slot, 0.25);
    }
    ctx.restore();
  });
  ctx.restore();
}

// Retrato: foto com leve contraste, véu da categoria (multiply) e degradê até
// a cor base na parte de baixo, recortado com cantos arredondados.
function drawPortrait(ctx: CanvasRenderingContext2D, image: HTMLImageElement | null, rect: CanvasRect, base: string) {
  const layer = document.createElement('canvas');
  layer.width = Math.round(rect.width);
  layer.height = Math.round(rect.height);
  const lctx = layer.getContext('2d');
  if (!lctx) {
    return;
  }
  const local = { x: 0, y: 0, width: layer.width, height: layer.height };

  lctx.fillStyle = mixHex(base, '#000000', 0.7);
  lctx.fillRect(0, 0, layer.width, layer.height);
  if (image) {
    drawCover(lctx, image, local, 0.15);
    adjustContrastBrightness(lctx, layer.width, layer.height, 1.1, 0.92);
    lctx.save();
    lctx.globalCompositeOperation = 'multiply';
    lctx.globalAlpha = 0.5;
    lctx.fillStyle = base;
    lctx.fillRect(0, 0, layer.width, layer.height);
    lctx.restore();
  }
  const gradient = lctx.createLinearGradient(0, 0, 0, layer.height);
  gradient.addColorStop(0.3, rgba(base, 0));
  gradient.addColorStop(0.58, rgba(base, 0.6));
  gradient.addColorStop(0.86, rgba(base, 0.97));
  gradient.addColorStop(1, rgba(base, 0.97));
  lctx.fillStyle = gradient;
  lctx.fillRect(0, 0, layer.width, layer.height);

  ctx.save();
  roundedRectPath(ctx, rect, 36);
  ctx.clip();
  ctx.drawImage(layer, rect.x, rect.y, rect.width, rect.height);
  ctx.restore();
}

// Equivalente ao filter: contrast() brightness() do CSS, feito em pixels
// porque ctx.filter não existe em Safaris mais antigos.
function adjustContrastBrightness(ctx: CanvasRenderingContext2D, width: number, height: number, contrast: number, brightness: number) {
  try {
    const data = ctx.getImageData(0, 0, width, height);
    const px = data.data;
    for (let i = 0; i < px.length; i += 4) {
      for (let c = 0; c < 3; c += 1) {
        const v = ((px[i + c] / 255 - 0.5) * contrast + 0.5) * brightness * 255;
        px[i + c] = v < 0 ? 0 : v > 255 ? 255 : v;
      }
    }
    ctx.putImageData(data, 0, 0);
  } catch {
    // Canvas contaminado: segue sem o ajuste, a foto ainda aparece.
  }
}

// object-fit: cover, com o ponto vertical de foco em `focusY` (0 = topo).
function drawCover(ctx: CanvasRenderingContext2D, image: HTMLImageElement, rect: CanvasRect, focusY: number) {
  const scale = Math.max(rect.width / image.naturalWidth, rect.height / image.naturalHeight);
  const width = image.naturalWidth * scale;
  const height = image.naturalHeight * scale;
  ctx.drawImage(
    image,
    rect.x + (rect.width - width) / 2,
    rect.y + (rect.height - height) * focusY,
    width,
    height
  );
}

function roundedRectPath(ctx: CanvasRenderingContext2D, rect: CanvasRect, radius: number) {
  const { x, y, width, height } = rect;
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}
