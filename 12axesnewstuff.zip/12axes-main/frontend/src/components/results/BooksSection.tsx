import { t } from '../../i18n';
import type { BookRecommendation } from '../../types/quiz';
import { personalityInitials, resolvePersonalityImageSrc } from '../../utils/personalityImage';
import { SafeImg } from '../editorial/primitives';

/**
 * Livros das personalidades mais compatíveis; link e tag de afiliado vêm prontos do backend.
 * O destaque usa --cat/--cat-bg, definidos pela ideologia principal no topo do resultado.
 */
export function BooksSection({ books }: { books?: BookRecommendation[] }) {
  if (!books || books.length === 0) {
    return null;
  }

  return (
    <section className="e-panel e-read" id="livros" aria-labelledby="livros-titulo" data-reveal>
      <header className="e-read-head">
        <div>
          <h2 id="livros-titulo">{t.booksTitle}</h2>
          <p className="e-read-lead">{t.booksLead}</p>
        </div>
      </header>
      <ul className="e-read-grid">
        {books.map((book, index) => (
          <li className={index === 0 ? 'e-read-card e-read-top' : 'e-read-card'} key={book.personalityId}>
            <div className="e-read-meta">
              <span className="e-read-rank">{String(index + 1).padStart(2, '0')}</span>
              <span className="e-read-pct">{t.booksWhy(Math.round(book.compatibility))}</span>
            </div>
            <div className="e-read-author">
              <SafeImg
                className=""
                src={resolvePersonalityImageSrc(book.imagePath)}
                alt={t.portraitAlt(book.personalityName)}
                fallback={personalityInitials(book.personalityName)}
              />
              <div>
                <span className="e-read-label">{index === 0 ? t.booksTopLabel : t.booksAuthorLabel}</span>
                <strong>{book.personalityName}</strong>
              </div>
            </div>
            <div className="e-read-book">
              <svg className="e-read-ico" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M4 19V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2" />
                <path d="M4 19a2 2 0 0 1 2-2h13" />
              </svg>
              <div>
                <h3>{book.title}</h3>
                {book.year ? <span className="e-read-year">{formatYear(book.year)}</span> : null}
              </div>
            </div>
            <a className="e-read-btn" href={book.url} target="_blank" rel="sponsored noopener noreferrer">
              {t.booksCta} <AmazonIcon />
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function AmazonIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <g fill="none">
        <path
          stroke="currentColor"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="1.3"
          d="M17.284 17.724h1.967c.543 0 .983.44.983.983v1.967"
        />
        <path
          fill="currentColor"
          fillRule="evenodd"
          clipRule="evenodd"
          d="m6.901 7.111l1.976.2a.57.57 0 0 0 .558-.34c.268-.573.924-1.59 2.209-1.59c.258 0 .478.041.665.108c1.04.373 1.02 1.77 1.02 2.874c0 0-2.415-.058-3.992.476c-.465.157-.934.333-1.36.578c-1.223.705-1.77 2.276-1.969 3.022c-.071.27-.098.549-.08.828c.08 1.178.558 3.184 2.968 3.599c2.247.386 3.749-.64 4.43-1.267c.23-.213.612-.22.817.018l.88 1.017a.59.59 0 0 0 .825.066l1.676-1.402a.59.59 0 0 0 .101-.796l-.267-.374c-.215-.3-.422-.613-.517-.97c-.099-.372-.09-.763-.09-1.148V6.704c0-2.372-2.295-3.681-3.94-3.85l-.592-.057a6 6 0 0 0-.972-.034a6 6 0 0 0-1.162.196c-1.537.399-3.348 1.765-3.597 3.664c-.033.25.162.463.413.488m6.428 4.576v-1.432s-1.905-.047-2.664.363c-.312.168-.574.491-.775.813a2.54 2.54 0 0 0-.291 1.94c.066.275.158.54.282.695c.259.323.876.439 1.166.476q.156.022.311.003c.157-.022.413-.08.67-.23c.39-.229.695-.595.903-.995c.118-.226.208-.471.273-.676a3.2 3.2 0 0 0 .125-.957"
        />
        <path
          stroke="currentColor"
          strokeLinecap="round"
          strokeWidth="1.5"
          d="M4.5 18.707c1.933 1.619 4.584 2.548 7.375 2.548c1.853 0 3.643-.41 5.203-1.158a11 11 0 0 0 .573-.295"
        />
      </g>
    </svg>
  );
}

function formatYear(year: number): string {
  return year < 0 ? t.booksYearBc(-year) : String(year);
}
