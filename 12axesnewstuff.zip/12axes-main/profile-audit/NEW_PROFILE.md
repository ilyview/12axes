# Criação de um novo perfil (país, ideologia, personalidade ou partido/organização)

Este arquivo descreve o processo completo para **criar um perfil totalmente novo** no projeto
12axes — diferente de `profile-audit/README.md`, que reaudita perfis já existentes. Use este
processo quando o usuário pedir para **adicionar** um país, ideologia ou personalidade que ainda
não existe no catálogo.

Se você é uma IA retomando este trabalho numa sessão nova, **leia este arquivo inteiro antes de
fazer qualquer coisa**. Ele é autossuficiente, mas reutiliza a metodologia de perguntas e cálculo
de vetor já documentada em `profile-audit/README.md` — leia esse arquivo também antes do passo 5.

## Gatilho

Quando o usuário disser algo como:

> "Quero que crie um novo perfil de ideologia/personalidade/país chamado XXXX, rode
> @NEW_PROFILE.md e faça a criação completa"

Execute os passos abaixo, na ordem, sem pular etapas. Pergunte ao usuário só o que for
estritamente necessário e não puder ser inferido (ver passo 0).

## Catálogo `party` (partidos, movimentos, casas dinásticas e organizações)

O catálogo `party` cobre partidos políticos, movimentos, casas dinásticas, organizações armadas e
organizações internacionais, **atuais e históricos** (NSDAP, Partido Republicano, PCCh, Vox, AIB,
Al-Qaeda, Casa de Habsburgo etc.). Processo, campos e regras em `.claude/skills/new-party/SKILL.md`;
reauditoria em `.claude/skills/audit-party/SKILL.md`. Diferenças em relação aos outros catálogos:

| Tema | Regra |
|---|---|
| Arquivos | `parties.json` (PT), `i18n/en/parties.json` (EN: `id`, `name`, `category`, `description`), `parties-profiles.json` (chave `partyId`), logos em `frontend/public/parties/logos/{id}.png` |
| Campos | `id`, `name`, `category`, `description`, `logoPath`, `logoSourceName`, `logoSourceUrl`, `logoNote`, `countryId`, `historical`, `period`, `religions` |
| `category` | valor fechado em PT: `Partido`, `Movimento`, `Casa dinástica`, `Organização armada`, `Organização internacional` (o EN traduz o rótulo). Bloqueado pelo backend e pelo `validate.py` |
| `countryId` | **obrigatório**, id de país existente do catálogo, atual ou histórico (o front mostra "Partido Republicano, Estados Unidos"). Organização sem Estado usa o país de maior associação |
| `id` | kebab-case sem acento; se o nome colide entre países ou eras, o `id` leva o país e/ou a era (`partido-republicano-eua`, `partido-republicano-eua-new-deal`) |
| `name` | Formato **"Nome do Partido (Sigla)"** ou só **"Nome do Partido"** (PT e EN). **Nunca** inclua o país no nome (nada de "(Sigla, País)" nem "(Hungria)"): a UI já mostra a bandeira e a descrição abaixo, então o país no nome é redundante e deixa o texto grande. Para distinguir eras ou ramos, use só o complemento ("Partido Republicano (era New Deal)", "Casa de Bourbon (ramo francês)"). |
| Eras | `historical: true` + `period` para o perfil de um período específico; a mesma organização em duas eras são dois perfis |
| Logo | símbolo oficial mostrado na Wikipédia (Commons), **sempre quadrado 1:1**: `npm run square:logo -- <baixado> public/parties/logos/{id}.png` (480x480 PNG transparente, sem distorcer nem cortar) |
| Auditoria | o subagente responde **como o próprio partido/grupo/organização, pela prática e pelas ideias e valores**, não pelo país (ver `README.md`, nota sobre `party`); prompt com parágrafo "FATO PÚBLICO E CALIBRAÇÃO" |
| Validação | `python profile-audit/validate.py party <id>` (forma, neutros, conteúdo, categoria, país, logo 1:1); duplicata ≥ 97% de outro partido bloqueia, em especial da mesma organização em outra era |
| Testes | `PartyCatalogTest` + `ReligionFilterTest`, `QuizResultPayloadTest`, `CompareControllerTest` |
| Matches | `python profile-audit/compatibility.py party <id>` imprime também o top 2 de partidos |

## Passo 0 — Reunir informações mínimas

Antes de escrever qualquer arquivo, você precisa saber:

1. **Catálogo**: `ideology`, `personality`, `country` ou `party` (ver seção "Catálogo `party`" acima).
2. **`id`**: slug em kebab-case, minúsculo, sem acento (ex.: `social-libertarianismo`,
   `xi-jinping`, `mongolia`). Verifique que não colide com nenhum `id` já existente no arquivo de
   metadados do catálogo (`ideologies.json` / `personalities.json` / `countries.json`).
3. **`name`**: nome de exibição em PT-BR.
4. Os demais campos dependem do catálogo — veja a tabela abaixo. Se o usuário não informou algo
   essencial (ex.: `category` de uma ideologia, `role`/`lifespan` de uma personalidade, se um país
   é `historical`), **decida com base em pesquisa/conhecimento factual e prossiga** — só pergunte
   ao usuário se a ambiguidade for genuinamente impossível de resolver sozinho (ex.: dois países
   homônimos, ou uma personalidade com nome muito comum).

### Pesquisa aprofundada obrigatória para personalidades vivas/contemporâneas

Duas sessões de IA independentes auditando a mesma pessoa viva **já produziram vetores
materialmente diferentes** (um caso real: `representacao` saiu 51 numa sessão e 76 noutra para o
mesmo perfil) porque cada uma parou a pesquisa em um nível de profundidade diferente. Rótulos
ideológicos genéricos ("liberal", "linha-dura", "nacionalista") não são suficientes para calibrar
240 respostas — é fácil "confirmar" um rótulo com 2 buscas rasas e deixar de fora exatamente os
fatos que mais moveriam o vetor.

Se o perfil é uma pessoa viva e politicamente ativa (sobretudo candidato ou titular de cargo em
mandato/campanha corrente), **antes de escrever a `description`**:

1. Não se contente com 1-2 buscas genéricas de biografia. Faça uma busca **dedicada por eixo**
   (ou pelo menos pelos eixos onde a pessoa tem posição pública conhecida), buscando fatos
   específicos e citáveis, não rótulos vagos — ex.: não "é liberal na economia", mas "defende
   processamento nacional de terras-raras e tarifas sobre importados chineses, mas se opõe a
   privatizar a Petrobras".
2. Cubra pelo menos: doutrina econômica concreta (privatizações defendidas/recusadas por nome,
   tarifas, protecionismo setorial), segurança pública (métodos citados nominalmente — ex.: cita
   outro líder/modelo como referência), estrutura federativa/administrativa (propostas concretas
   de centralização ou descentralização), política externa, costumes/moral, religião, e qualquer
   controvérsia recente com citação direta.
3. Cruze pelo menos 3 fontes independentes e note a data de cada fato — priorize o que é mais
   recente em relação à data atual da conversa.
4. **Antes de prosseguir para o Passo 1**, releia os 12 eixos do resumo rápido de
   `profile-audit/README.md` e verifique: para cada eixo, você tem pelo menos um fato específico e
   sourced, ou só uma inferência genérica a partir do rótulo ideológico? Se algum eixo só tem
   inferência genérica, faça mais uma busca dedicada a ele antes de escrever a `description`.
5. Inclua na `description` (ou no contexto adicional do prompt de auditoria do Passo 5) os fatos
   concretos mais reveladores — inclusive os que geram tensão ou contradição com o rótulo
   ideológico principal da pessoa. É exatamente essa tensão que o vetor de 12 eixos deveria
   capturar; suavizá-la no texto produz um vetor raso.

Essa mesma checklist vale ao **reauditar** um perfil de pessoa viva já existente
(`profile-audit/README.md`) — antes de gerar o prompt do lote, confirme que a `description` atual
ainda reflete a posição mais recente da pessoa; se não refletir, atualize `personalities.json` /
`ideologies.json` (Passo 1 deste arquivo) antes de prosseguir.

| Catálogo | Campos obrigatórios | Campos condicionais |
|---|---|---|
| `ideology` | `id`, `name`, `category`, `description`, `phrase`, `countryId`, `personalityId`, `religions` | `phrase` só existe neste catálogo, ver seção própria |
| `personality` | `id`, `name`, `role`, `lifespan`, `description`, `imagePath`, `imageSourceName`, `imageSourceUrl`, `imageNote`, `religions` | — |
| `country` | `id`, `name`, `category`, `description`, `flagPath`, `historical`, `period`, `vector` (sempre `null` no arquivo de metadados), `religions` | `period` só é preenchido (e `historical: true`) se o perfil representa um país num momento histórico específico (ex.: "Alemanha Nazista — Terceiro Reich") |

**Nota sobre `ideology.countryId` / `ideology.personalityId`**: toda ideologia do catálogo aponta
para um país e uma personalidade **já existentes** que a exemplificam bem (ex.: `aceleracionismo-cristao`
→ `countryId: "eua-texas"`, `personalityId: "peter-thiel"`). Escolha o país/personalidade mais representativo
já presente no catálogo. Isso é validado por `IdeologyPersonalityMappingTest` e
`IdeologyCountryMappingTest` — se apontar para um id inexistente, o build quebra.

## Passo 1 — Adicionar aos metadados em português (fonte da verdade)

Adicione um novo objeto ao **final** do array JSON correspondente:

- `ideology` → `backend/src/main/resources/data/ideologies.json`
- `personality` → `backend/src/main/resources/data/personalities.json`
- `country` → `backend/src/main/resources/data/countries.json`

Escreva a `description` em português, no mesmo estilo enxuto e factual dos outros perfis do
catálogo (1 a 3 frases, sem opinião, citando fatos/características concretas verificáveis). Leia
2-3 exemplos vizinhos no mesmo arquivo para calibrar tom antes de escrever o seu.

**Tamanho padrão** (medido nos três catálogos em 2026-09-16, n=609):

| catálogo | média | mediana | faixa central (p10-p90) |
|---|---|---|---|
| personality | 222 car. / 31 pal. | 212 car. / 30 pal. | 201-268 caracteres |
| ideology | 216 car. / 31 pal. | 209 car. / 30 pal. | 202-244 caracteres |
| country | 221 car. / 31 pal. | 217 car. / 30 pal. | 205-250 caracteres |

Mire **~30 palavras / ~220 caracteres**; o teto é **45 palavras / 280 caracteres**. Depois de
escrever, **confira a contagem antes de salvar**:

```python
print(len(desc), 'caracteres,', len(desc.split()), 'palavras')
```

Se passar do teto, corte o que for redundante ou secundário — cite só os 2-3 fatos mais definidores
do perfil, nunca uma lista exaustiva de posições. A mesma regra vale para a tradução em inglês do
Passo 2 e para **qualquer atualização posterior** da description (inclusive as feitas durante uma
reauditoria de perfil vivo): atualizar não é motivo para a description crescer. Quando acrescentar
um fato novo, corte outro menos importante para compensar.

Exemplo de objeto novo em `ideologies.json`:

```json
{
  "id": "exemplo-ideologia",
  "name": "Exemplo de Ideologia",
  "category": "Centro",
  "description": "Descrição factual de 1-3 frases sobre a ideologia, seus princípios centrais e contexto histórico/geográfico relevante.",
  "phrase": "Quero uma sociedade ... (ver seção sobre o campo phrase abaixo)",
  "countryId": "brasil",
  "personalityId": "lula-da-silva",
  "religions": []
}
```

Exemplo de objeto novo em `countries.json`:

```json
{
  "id": "exemplo-pais",
  "name": "Exemplo",
  "category": "República parlamentarista",
  "description": "Descrição factual de 1-3 frases sobre o país/período, seu regime político e economia.",
  "flagPath": "/countries/flags/exemplo-pais.gif",
  "historical": false,
  "period": "",
  "vector": null,
  "religions": ["catholic"]
}
```

Exemplo de objeto novo em `personalities.json` (campos de imagem preenchidos no passo 3):

```json
{
  "id": "exemplo-pessoa",
  "name": "Exemplo Pessoa",
  "role": "Fundador do Partido Exemplo",
  "category": "politico",
  "lifespan": "1900–1980",
  "description": "Descrição factual de 1-3 frases sobre a trajetória e ideias da pessoa.",
  "imagePath": "/personalities/portraits/exemplo-pessoa.jpg",
  "imageSourceName": "Wikimedia Commons / Wikipédia",
  "imageSourceUrl": "https://pt.wikipedia.org/wiki/Exemplo_Pessoa",
  "imageNote": "Retrato de Exemplo Pessoa via Wikipédia/Wikimedia Commons.",
  "religions": ["catholic"]
}
```

### O campo `category` (só personalidades)

`category` é **obrigatório** e agrupa a pessoa na seção "Também próximos, por área de
atuação" da página de resultados. São **8 valores fechados** — nunca invente um novo:

| valor | abrange |
|---|---|
| `politico` | chefes de Estado, estadistas, ditadores, monarcas, imperadores, parlamentares |
| `religioso` | líderes e fundadores religiosos, teólogos |
| `economista` | economistas e teóricos econômicos |
| `filosofo` | pensamento geral e abstrato: ética, metafísica, epistemologia, filosofia política clássica |
| `teorico` | formuladores de doutrina política/social específica e operacional |
| `empresario` | empresários, industriais, investidores |
| `intelectual` | escritores, jornalistas, juristas, cientistas, militares, historiadores |
| `ativista` | militantes de movimentos sociais e de direitos civis |

**`role` e `category` são coisas diferentes.** `role` é um texto curto que responde **"quem é
essa pessoa e por que ela é conhecida?"** (ver a subseção abaixo); `category` agrupa. Stálin
é `role: "Líder da União Soviética"` com `category: "politico"`.

### O campo `role` (só personalidades)

O `role` aparece no card da personalidade, nos resultados e no **card de compartilhamento
(imagem)**, onde texto grande quebra feio. Ele diz por que a pessoa é conhecida, não apenas a
ocupação. Vale para o PT (`personalities.json`) e para o EN (`i18n/en/personalities.json`), que
dizem a mesma coisa.

1. **Tamanho:** no máximo **30 caracteres e 5 palavras** (meta: 4 ou menos), em PT **e** EN.
2. **Diga por que é conhecida**, com o fato que mais a define:
   - fundador, líder ou pai de algo: "Pai da psicanálise", "Fundador da Kyocera", "Cofundador da
     Microsoft", "Fundador do epicurismo", "Líder do Levante de Páscoa";
   - obra que a define: "Autor de Os Sertões", "Autor de Bronze Age Mindset";
   - marca de identidade: "Unabomber", "Último Kaiser alemão", "Médico dos Pobres";
   - **cargo com ordinal** quando o cargo é o motivo da fama: "37º Presidente dos EUA", "4º
     Presidente do Brasil", "50º Vice-presidente dos EUA". O ordinal precisa estar **correto**;
     sem certeza, use o cargo sem ordinal ou outra forma específica, nunca um número chutado;
   - monarcas: "Rei de X", "Imperador de Y"; pensadores: a corrente, não só "Filósofo" ("Filósofo
     estoico romano", "Teórico situacionista", "Pioneiro do anarquismo").
3. **Evite o rótulo genérico sozinho** ("Estadista", "Político", "Filósofo", "Economista",
   "Ditador", "Revolucionário", "Escritor", "Empresário") quando existe um fato específico que
   define a pessoa; mantenha o genérico só quando nada a define melhor.
4. **Sem listas de profissões** ("Inventor, Fabricante e Filósofo"): escolha o que mais a define.
5. **Capitalização:** só a inicial maiúscula ("Fundador dos jesuítas"), mantendo nomes próprios e a
   maiúscula depois do ordinal ("4º Presidente do Brasil", "4th President of Brazil"). Sem ponto
   final; período entre parênteses só se indispensável ("Líder da China (1989–2002)").
6. **EN:** tradução natural, não literal, com as mesmas regras; generalize referências
   brasileiras que um estrangeiro não entenderia (STF → "Supreme Court justice"; nomes próprios
   de obras e partidos ficam).
7. **Precisão factual:** não invente fatos, datas nem ordinais. Pessoa viva: o cargo ou fama
   atual; "Ex-" quando já deixou o cargo que a define.

**O que entra em `religioso`.** A categoria não mede a fé da pessoa, e sim **o tema da obra
dela**: entram tanto quem construiu uma tradição religiosa quanto quem a atacou ou tentou
substituí-la. A favor, Tomás de Aquino, Lutero, Calvino, Khomeini, Dalai Lama; contra ou fora,
Nietzsche (*O Anticristo*), Auguste Comte (fundou a Religião da Humanidade), Charles Darwin (a
evolução desfez a religião natural; dizia-se agnóstico) e Confúcio (tradição ético-religiosa
não-abraâmica). Sem isso a categoria só serve a quem tira pontuação religiosa baixa, e o card de
resultados fica sem match decente para perfis irreligiosos. **Ser apenas irreligioso não basta**:
Lênin, Marx e Che Guevara pontuam alto em `religiao`, mas a obra deles é revolução, não religião.

**Fronteira `filosofo` × `teorico`** (a que mais gera erro): `filosofo` é pensamento geral e
abstrato (Platão, Kant, Rawls, Arendt); `teorico` formulou doutrina política ou social
específica e operacional (Marx, Gramsci, Bakunin, Mackinder). Quando a pessoa é genuinamente
as duas coisas, decida pelo motivo de ela estar num catálogo de política: Marx é `teorico`
porque o marxismo é um programa; Arendt é `filosofo` porque a obra dela é análise.

Quem exerceu poder de Estado e também escreveu teoria (Lênin, Mao) entra como `politico` se o
exercício do poder é o que define a figura, e `teorico` se a obra escrita é o que define.

`category` vive **apenas no arquivo PT** — o catálogo EN traduz só `name`, `role` e
`description`, e a categoria é propagada pelo backend. Não adicione `category` ao i18n.

O teste `PersonalityCategoryTest` falha se qualquer perfil ficar sem `category` ou usar um
valor fora dos 8.

### O campo `religions` (os três catálogos)

`religions` é **obrigatório** (use `[]` quando não houver vínculo) e alimenta o filtro opcional
"priorizar uma tradição religiosa" da página de resultados. Valores fechados:
`catholic`, `protestant`, `orthodox` (o cristianismo é dividido por denominação; perfil ambíguo ou sem denominação leva mais de uma, ou as três), `judaism`, `islam`, `buddhism`, `hinduism` e `other` (xintoísmo, sikhismo, religiões
antigas/pagãs etc.). Pode haver mais de um.

**Primeiro filtro: o vetor.** Só se marca religião quando ela muda a decisão de quem filtra:
- `religiao` ≤ 35 (lado religioso): marcação **obrigatória**, pelo critério de cada catálogo abaixo.
- `religiao` > 35: `[]` por padrão, porque o perfil é laico o bastante para que um fiel de outra
  tradição possa se identificar com ele (um cristão pode gostar do sistema político de Singapura).
  A exceção é quando a religião é a própria identidade do perfil: doutrina religiosa por definição
  (Anarquismo Cristão, Liberalismo Islâmico) ou liderança/fundação religiosa ou nacional-religiosa
  (Dalai Lama, Ambedkar, Tolstói, Herzl, Jinnah). Em **personalidades**, também entra quem tem
  posição política ou religiosa forte ligada à fé (Milei, Chávez, Biden, Blair, Thiel, Mamdani).
  Só `["other"]` pode ficar em qualquer caso,
  porque não afeta o filtro.

**Regra de inclusão (por catálogo).** O teste é um só: **a religião é parte relevante daquilo que
o perfil representa?** O filtro *esconde* os perfis marcados só com outra religião, então cada
marcação tira o perfil de quem escolheu outra tradição. Marque só quando isso fizer sentido.

| Catálogo | Entra | Não entra |
|---|---|---|
| país | **só a religião majoritária** (ou a tradição dominante), mesmo em Estado laico (Arábia Saudita = `["islam"]`; Polônia = `["catholic"]`; Suécia e Albânia, laicas no vetor, = `[]`) | religiões minoritárias, por maiores que sejam; regimes cuja marca é a perseguição à religião (Coreia do Norte, Khmer Vermelho, URSS = `[]`) |
| ideologia | doutrina com base religiosa explícita (Democracia Cristã, Islamismo, Distributismo, Baathismo) ou que defende uma religião como parte da identidade política (Teocratismo Cristão, Fundamentalismo Religioso) | doutrinas seculares, mesmo com adeptos majoritariamente de uma religião |
| personalidade | fé pública que aparece na atuação, liderança religiosa, ou apoio declarado a uma causa religiosa (Khomeini, Churchill, Martin Luther King Jr.) | origem étnica ou cultural sem papel na vida pública (Einstein, Friedman, Kafka = `[]`); fé privada de figuras seculares; apoio político a Israel, que não é causa judaica (sionismo cristão = a denominação da pessoa (Trump = `protestant`); judeu secular sionista como Einstein ou Isaiah Berlin = `[]`) |

Aliança só diplomática/militar **não** conta. Ex.: Trump = `["protestant"]` (o sionismo
cristão é causa cristã); Arábia Saudita = `["islam"]`, apesar da aliança com os EUA.

**Como o filtro trata `other`:** um perfil aparece se contém a religião escolhida **ou** se não
tem nenhuma das selecionáveis (`[]` ou só `["other"]`). Junto de outra religião,
`other` é só informativo: `["buddhism", "other"]` some para quem escolheu cristianismo.
**`["other", "only"]`** (xintoísmo e afins): o perfil some para quem escolheu qualquer religião
selecionável e aparece só para quem não escolheu nenhuma (Aristóteles, só `["other"]`, continua
aparecendo para todos). O usuário também pode escolher **"Outra religião"** (`religion=other`):
nesse caso some todo perfil ligado a uma religião selecionável (inclusive `["buddhism", "other"]`
e `["judaism", "only"]`) e ficam os só com `other` (inclusive `["other", "only"]`) e os seculares (`[]`).

**Texto secular com vetor religioso:** se a descrição diz que o perfil é secular mas o vetor tem
`religiao` ≤ 35, a marcação não pode sair. Registre o perfil para reauditar o vetor em vez de
apagar a religião.

**Obrigatório ter ao menos um valor** quando o vetor final tiver `religiao` ≤ 35 (polo
irreligioso; baixo = religioso). O valor vem de pesquisa, **nunca** do vetor: o vetor só torna o
campo obrigatório. `religions` vive **apenas no arquivo PT**, como `category`.

Como o filtro funciona: com uma religião escolhida (no cristianismo, uma das três vertentes), some só o
perfil ligado a outra das religiões selecionáveis e não à escolhida. Perfis `[]` ou só `other` sempre aparecem (`["other", "only"]` é a exceção, ver acima). A
compatibilidade não muda. `validate.py` ([RELIGIAO]) e `ReligionFilterTest` bloqueiam o merge se a
regra for violada.

### Vertente cristã (`catholic`, `protestant`, `orthodox`)

O cristianismo é dividido em três vertentes. Na tela de resultado o usuário escolhe a religião e,
se for cristianismo, a vertente; cada perfil cristão leva uma, duas ou as três marcas. O filtro
esconde os perfis ligados só a outra vertente. Marcar a vertente errada tira o perfil de quem
deveria vê-lo, então toda marca precisa de **base explícita**.

**Regras gerais (os três catálogos)**
- **Nunca há padrão silencioso.** Nada de "católico por omissão": o perfil sem base clara fica
  marcado como **provisório** no resumo da auditoria, para revisão humana.
- **Tamanho da marca:** 1 vertente (clara), 2 (ambígua ou de transição) ou 3 (pan-cristã de fato).
  Nunca 4 ou mais marcas cristãs.
- **Na dúvida, duas marcas em vez de uma errada.** Marcar a mais só aumenta a visibilidade;
  marcar errado esconde o perfil de quem deveria vê-lo.
- **Ordem do campo:** `catholic`, `protestant`, `orthodox`, depois as não cristãs, depois
  `other`, depois `only`. Marcas não cristãs e `only` não se alteram ao auditar a vertente.
- **Cristãos fora das três** (mórmons, Testemunhas, unitaristas): ficam com a tradição de origem
  se for clara; senão, com as três, registrando a ressalva.

**Países e regiões** (aplique na ordem; a primeira regra que servir decide)
1. **Igreja estatal ou religião oficial** na época do perfil define a marca (Rússia =
   `["orthodox"]`; Inglaterra vitoriana = `["protestant"]`; Espanha franquista = `["catholic"]`).
2. **Participação:** uma vertente com **65% ou mais** dos cristãos, na época do perfil, é a marca única.
3. **Segunda comunidade:** com **25% ou mais** dos cristãos, ou quando a divisão molda a política
   (Suíça, Hungria, Alemanha imperial, Líbano, Irlanda do Norte), marcam-se as duas.
4. **Perfil histórico:** vale a vertente do **período** que o perfil representa, não a de hoje
   (Brasil Império = `catholic`; República Holandesa = `protestant`).
5. **Antes do cisma de 1054** (Império Romano) ou perfil que o atravessa (Império Bizantino):
   `catholic` e `orthodox`, ou as três quando o reconhecimento é pan-cristão.
6. **Regiões** (estado, província, cantão): a vertente dominante **da região**, não a do país.
7. **Estado laico ou que perseguiu a religião:** sem marca, salvo se o vetor (`religiao` ≤ 35)
   exigir; aí vale a tradição cultural histórica do povo.

**Personalidades** (use a evidência mais forte disponível)
1. **Identidade religiosa pública** durante a atividade política ou intelectual (declaração,
   filiação, culto, obra).
2. **Pertencimento formal** (membro de igreja, ordem ou conselho).
3. **Nascimento ou batismo**, só se não houver mudança nem sinal em contrário.
4. **Contexto cultural**, só como último recurso, e sempre **provisório**.

Casos especiais:
- **Conversão:** vale a vertente do período de influência pública; se a carreira atravessa as duas,
  marcam-se as duas (Blair, Vance, Lacerda).
- **Anglicano, episcopal, presbiteriano, luterano, calvinista, metodista, batista, evangélico,
  pentecostal, quaker:** `protestant`. O anglicano só ganha também `catholic` se a pessoa se
  identificava como anglo-católica ou defendia doutrina católica.
- **Ortodoxo oriental, pré-calcedoniano e velhos crentes:** `orthodox`. **Católico oriental:**
  `catholic`.
- **Antes de 1517 no Ocidente:** `catholic`. **Antes de 1054 no Oriente:** `orthodox`. **Pais da
  Igreja e apóstolos** (Paulo, Agostinho), reconhecidos pelas três: as três.
- **Heterodoxo ou excomungado** (Tolstói, Newton): a tradição de origem, mais a mais próxima se a
  identidade cristã era assumida.
- **Fé declarada em disputa:** as duas vertentes plausíveis. **Cristianismo só cultural:** sem
  marca, salvo se o vetor exigir. **Pessoas vivas:** só o que é público e declarado.

**Ideologias** (classifique a **doutrina**, nunca o país ou a pessoa de referência)
1. A definição depende de uma teologia ou autoridade eclesiástica específica (magistério papal,
   tomismo, "Deus, Pátria, Foros e Rei", fascismo clerical)? **Só essa vertente** (ou as que a
   descrição nomeia).
2. Exige fé cristã em geral, mas não uma vertente (Democracia, Socialismo, Anarquismo e Trabalhismo
   Cristãos)? **As três**; mantém `only` se for exclusiva de cristãos.
3. É doutrina política que funciona sem religião (monarquismo, federalismo, conservadorismo,
   imperialismo, nacionalismos, militarismo)? **Neutra:** as sete religiões selecionáveis (o
   validador exige ao menos uma marca quando `religiao` ≤ 35), mantendo `other`/`only`.

Dois testes de apoio: o **teste da troca** (troque o país ou a pessoa de referência por um de outra
religião; se a doutrina ainda faz sentido, ela é neutra) e **origem não basta** (nascer num
ambiente católico, como o Distributismo ou o Falangismo, só conta se a **essência** da doutrina
depende da vertente, e não só o contexto histórico).

**Ao auditar,** liste no resumo, para cada perfil cristão do lote, a marca e a **base**
(igreja estatal, participação, duas comunidades, período histórico, pré-cisma, região,
autodeclaração, pertencimento, nascimento, definição da doutrina, cristã em geral, neutra) e
destaque os **provisórios**.


**Marcador `only` (perfil exclusivo).** Acrescente `"only"` ao lado de uma ou mais religiões
selecionáveis (ex.: `["judaism", "only"]`) para que o perfil apareça **apenas** para quem escolheu
uma das religiões listadas. Quem escolheu "nenhuma" ou não escolheu nada também não o vê. Serve para
perfis em que a religião é a própria identidade (Sionismo Trabalhista, Cristianismo Anarquista),
onde um ateu ou fiel de outra tradição ver o perfil gera estranhamento. Vale para qualquer
`religiao`, inclusive ≤ 35, e a decisão é caso a caso: perfil que um não religioso pode legitimamente
preferir (Biden, Thiel) **não** leva `only`. O marcador precisa de ao menos uma religião
selecionável ao lado (`validate.py` e `ReligionFilterTest` bloqueiam `["only"]` ou
`["other", "only"]`), nunca entra no EN, e não muda a compatibilidade, só quem aparece.

### O campo `phrase` (só ideologias)

`phrase` é **obrigatório** e alimenta o card "Uma frase que te descreve" na página de resultados,
usando a frase da ideologia mais compatível com o usuário.

**É uma frase em primeira pessoa que diz o que a ideologia realmente defende.** Não é uma
descrição de coordenadas nos eixos.

Estrutura: três partes, nesta ordem, com **liberdade total de redação** em cada uma:

1. **Sociedade / cultura / valores** — o que a corrente quer como base da vida em comum
2. **Regime político** — como o poder se organiza e se legitima
3. **Economia** — como produção e propriedade se organizam

Comece com "Quero uma sociedade" ou "Quero um/uma ..." quando couber melhor à corrente. **Não** use
o esqueleto fixo "culturalmente X, politicamente Y, economicamente Z" — ele produz frases
intercambiáveis que não distinguem nada.

Exemplos do padrão esperado:

| ideologia | frase |
|---|---|
| Nacional-Socialismo | Quero uma sociedade baseada na raça ariana, politicamente hierárquica e autoritária, com um capitalismo de estado forte e protecionista. |
| Socialismo Stalinista | Quero uma sociedade sob líder forte e partido único, com coletivização agrária, planos quinquenais e industrialização acelerada. |
| Anarcocapitalismo | Quero abolir o Estado e organizar tudo por contratos e mercados livres, com segurança e justiça vendidas por empresas privadas. |
| Zapatismo | Quero comunidades indígenas autônomas decidindo em assembleias e caracoles, cooperativas de subsistência, mandando ao obedecer ao povo. |

Contraexemplo (**não faça assim** — foi a primeira versão do stalinismo, e foi rejeitada):

> Quero uma sociedade culturalmente assimilacionista e irreligiosa, politicamente autocrática e
> centralizada, economicamente estatizada e fechada.

Assimilacionismo não é característica central do stalinismo; é só onde ele cai num eixo. A frase
serviria para dezenas de outras correntes.

**Regras:**

- **Parta da `description`**, que contém as ideias centrais. O vetor em `ideology-profiles.json`
  serve como **trava**: a frase não pode contradizê-lo (se `representacao=8`, não escreva
  "democrática"; se `economia=90`, não escreva "livre mercado").
- Use o **vocabulário próprio da corrente**: soviete, califado, corporação, cooperativa, coroa,
  vanguarda, ordem espontânea, tradição, raça, classe, nação.
- **Única no catálogo.** Se lembrar de outra ideologia com frase parecida, reescreva até a diferença
  ficar visível.
- Tamanho: mire **~135 caracteres / ~18 palavras**; teto de **170 caracteres / 25 palavras**.
- Primeira pessoa, sem travessão, terminando em ponto final.
- Escreva como o **adepto sincero** escreveria, mesmo para ideologias repugnantes. É o ponto de
  vista interno dela, sem ironia nem julgamento.

`IdeologyPhraseTest` falha se alguma ideologia ficar sem frase, fora do tamanho, sem começar com
"Quero", sem ponto final, ou com frase repetida.

## Passo 2 — Traduzir para inglês

Adicione o mesmo objeto (traduzido) ao **final** do array correspondente em:

- `backend/src/main/resources/data/i18n/en/ideologies.json`
- `backend/src/main/resources/data/i18n/en/personalities.json`
- `backend/src/main/resources/data/i18n/en/countries.json`

Regras de tradução (confirmadas comparando os pares PT/EN já existentes nesses arquivos):

- `id` **nunca muda** — é o mesmo slug em ambos os idiomas.
- `name`, `category`, `description` são traduzidos para inglês natural, mantendo o mesmo nível de
  precisão factual do original em PT.
- Campos técnicos/estruturais (`countryId`, `personalityId`, `flagPath`, `imagePath`,
  `imageSourceUrl`, `historical`, `period`, `vector`) **não aparecem** no arquivo i18n de
  `ideologies.json`/`countries.json`/`personalities.json` — o i18n só tem `id`, `name`,
  `category`/`role`+`lifespan`, `description` (confira o arquivo real antes de assumir, o formato
  pode ter mudado desde a escrita deste documento).
- **Exceção: `phrase` (só `ideologies.json`) também precisa existir no i18n.** É o único campo de
  conteúdo (não estrutural) que fica de fora da lista acima — sem ele, o card "A sentence that
  describes you" da página de resultados em inglês exibe a frase em português (o backend cai no
  fallback PT quando a tradução falta). Traduza a `phrase` seguindo as mesmas regras da seção
  "O campo `phrase`" (primeira pessoa, começa com "I want", ~135 caracteres/~18 palavras, teto
  170/25, sem esqueleto fixo), nunca uma tradução literal palavra-por-palavra que estoure o padrão.
- Referências específicas do Brasil na `description` em PT (ex.: STF, Bolsa Família, um estado
  brasileiro) devem ser generalizadas ou removidas na versão em inglês, não traduzidas
  literalmente — a versão EN é para público internacional. Veja `[[en-content-internationalized]]`
  se essa memória existir; caso não exista mais, aplique o mesmo princípio por bom senso.

Os demais idiomas (`i18n/es/`, `i18n/de/` e `i18n/it/`) são gerados a partir do inglês, nunca à mão: rode
`python i18n-tools/sync.py status es` (e `status de`, `status it`) depois de mesclar para ver o que falta, e `extract` e `apply`
para traduzir só o novo (detalhes no topo de `i18n-tools/sync.py`). Até lá, o perfil aparece em
inglês nesses idiomas e nada quebra. Reauditar um perfil existente não gera tradução nenhuma.

## Passo 3 — Baixar a imagem (country: bandeira / personality: retrato)

**Só se aplica a `country` e `personality`** — ideologias não têm imagem própria.

### Country (bandeira)

1. Veja o `flagPath` de 2-3 países vizinhos no `countries.json` para confirmar o padrão de nome de
   arquivo (`/countries/flags/{id}.gif`, mas confira — alguns perfis mais recentes usam `.png`,
   veja `africa-do-sul-do-apartheid.png` como exemplo de exceção histórica).
2. Baixe uma imagem de bandeira de fonte confiável (Wikimedia Commons é o padrão usado no resto do
   catálogo) para `frontend/public/countries/flags/{id}.{ext}`.
3. Ajuste `flagPath` em `countries.json` (e o campo equivalente em `i18n/en/countries.json`, se
   existir) para bater exatamente com o arquivo salvo.
4. Para países históricos (`historical: true`), procure a bandeira do período específico, não a
   atual (ex.: bandeira do Terceiro Reich, não a bandeira alemã atual).
5. **Comprima a imagem imediatamente após o download** — ver "Compressão obrigatória" abaixo.

### Personality (retrato)

1. Baixe uma foto em retrato (rosto visível, formato vertical ou quadrado preferencialmente) da
   Wikipédia/Wikimedia Commons da pessoa, salvando em
   `frontend/public/personalities/portraits/{id}.jpg`.
2. Preencha em `personalities.json`:
   - `imagePath`: `/personalities/portraits/{id}.jpg`
   - `imageSourceName`: normalmente `"Wikimedia Commons / Wikipédia"` (padrão do catálogo)
   - `imageSourceUrl`: URL da página da Wikipédia (ou Wikimedia Commons) de onde a imagem veio
   - `imageNote`: frase curta em PT, ex. `"Retrato de {name} via Wikipédia/Wikimedia Commons."`
3. **Restrição validada por teste** (`IdeologyPersonalityMappingTest.everyPersonalityImagePathPointsToAPublicAsset`):
   o arquivo referenciado em `imagePath` precisa existir de fato em `frontend/public/...` — se o
   download falhar ou o caminho não bater exatamente, o build de testes quebra.
4. **Comprima a imagem imediatamente após o download** — ver "Compressão obrigatória" abaixo.

Se não for possível baixar uma imagem real (ex.: sem acesso à internet neste ambiente), documente
isso claramente para o usuário em vez de inventar/simular um download — não prossiga fingindo que
a imagem foi salva.

### Compressão obrigatória (sempre, para qualquer imagem baixada da internet)

Imagens da Wikimedia Commons frequentemente vêm em resolução/peso muito acima do necessário — já
tivemos um retrato de **52 MB** para uma imagem exibida a ~220px no site, e no total isso consumiu
mais de 100 MB no catálogo, disparando os limites de Fast Data Transfer/Edge Requests do plano
gratuito da Vercel. Nenhum download de imagem (bandeira ou retrato) fica sem esse passo:

```powershell
cd frontend
npm run optimize:images -- public/countries/flags/{id}.{ext}
# ou, para retrato:
npm run optimize:images -- public/personalities/portraits/{id}.jpg
```

O script (`frontend/scripts/optimize-images.mjs`) redimensiona para no máximo 480px de largura
(2x o tamanho real de exibição no site) e recomprime no **mesmo formato** do arquivo original
(preserva transparência em PNG quando existir; nunca renomeia o arquivo), então não quebra nenhuma
referência em `imagePath`/`flagPath`. Rode-o **antes** do Passo 4 (conferência de consistência),
como parte do mesmo passo de download — não deixe para depois nem trate como opcional. Depois de
rodar, confira visualmente a imagem otimizada (abra o arquivo) para garantir que a compressão não
degradou a legibilidade antes de prosseguir.

## Passo 4 — Conferir consistência dos metadados

Antes de seguir para a auditoria, releia os quatro (ou dois, se for ideologia) arquivos JSON
editados e confirme:

- JSON válido (sem vírgula sobrando, aspas balanceadas).
- O novo objeto está no fim do array, sem quebrar a formatação dos objetos vizinhos.
- `id` idêntico em todos os arquivos onde aparece (metadados PT, metadados EN).
- Nenhum campo obrigatório da tabela do passo 0 ficou vazio ou `null` (exceto os campos que são
  legitimamente `null`/`""` por padrão, como `vector: null` e `period: ""` em países não
  históricos).

## Passo 5 — Auditar o novo perfil (gerar o vetor de 12 eixos)

Este passo reusa **integralmente** o protocolo de `profile-audit/README.md`, passos 2 a 5, mas
para um único perfil novo (não um lote de 15):

1. Leia `profile-audit/README.md` inteiro se ainda não leu nesta sessão.
2. Monte o prompt do perfil usando o template da seção "2. Gerar o prompt de cada perfil do lote"
   do README, preenchendo os metadados que você acabou de criar no passo 1 (não os do i18n em
   inglês — o prompt de auditoria sempre usa os metadados em português, como os outros perfis).
   Salve em `profile-audit/prompts/<catalog>/<id>.txt`. O prompt termina com o bloco das
   **perguntas de arquétipo** (`python profile-audit/profile_vector.py --prompt-block`): o perfil
   responde as 240 perguntas **e** o arquétipo, como um usuário do quiz, e as duas partes entram no
   vetor (ver "Perguntas de arquétipo" no README).
   **Só para `country`:** Responda como o REGIME. O prompt de cada país deve conter (já está no template de `profile-audit/README.md`) a instrução de que o subagente responde como o governo/regime em exercício (ou, em país histórico, o regime daquele período) responderia, pela sua prática institucional real, e não pelo que a população, a oposição ou a Constituição afirmam. Em `representacao`, eleição formal, parlamento e Constituição democráticos não contam quando há fraude, oposição excluída ou perseguida, imprensa controlada, Judiciário submisso, partido/dinastia/Exército que não perde o poder ou ausência de eleições. As perguntas de `representacao` são normativas, e sem essa regra o subagente responde pelo ideal da sociedade e deixa regimes autoritários ou híbridos em 55–90. Em democracias reais o regime responde democraticamente. Para país com regime contestado ou híbrido, acrescente no prompt um parágrafo "FATO PÚBLICO DE CONTEXTO" (Democracy Index/Freedom House/V-Dem e histórico recente) como contexto, nunca como alvo numérico.
3. Dispare **um único subagente** (não precisa ser em lote de 15 — é só um perfil) com esse prompt,
   usando um modelo de qualidade (Sonnet ou superior — nunca Haiku ou modelo rápido/barato).
4. Valide a saída rodando **`python profile-audit/validate.py <catalog> <id>`**. Ele checa forma,
   taxa de neutros e conteúdo (direção dos eixos, duplicata, coerência com o perfil declarado) e
   bloqueia o merge se algo grave falhar. **Leia os avisos, não só o código de saída** — validação
   de forma sozinha já deixou passar erros graves. Ver "Modos de falha conhecidos" no README.

   Para perfil **novo**, dois pontos merecem atenção especial:
   - **Duplicata**: se o vetor sair ≥95% idêntico a um perfil existente, ele é redundante. Antes de
     gerar o prompt, liste os vizinhos prováveis e diga ao subagente o que diferencia o novo deles.
   - **Coerência**: uma ideologia deve bater alto com o `personalityId` que declara. Abaixo de ~92%,
     um dos dois vetores está errado — compare eixo a eixo e descubra qual antes de mesclar.
5. Calcule o vetor com o script Python de referência da seção "5." do README — que importa
   `compute_vector` de `profile-audit/profile_vector.py` e já soma as perguntas de arquétipo (adapte
   `ids_neste_lote` para conter só o novo `id`) e mescle no arquivo de perfis correspondente:
   - `ideology` → `backend/src/main/resources/data/ideology-profiles.json`
   - `personality` → `backend/src/main/resources/data/personality-profiles.json`
   - `country` → `backend/src/main/resources/data/countries-profiles.json`

   Como o perfil é novo (não existe ainda no array), o script precisa **acrescentar** um objeto
   novo em vez de só atualizar um existente. Ajuste assim:

   ```python
   # ... (mesmo setup do script de referência do README) ...
   pid = "<id-do-novo-perfil>"
   d = json.load(open(f'profile-audit/subagent-out/{CATALOG}/{pid}.json', encoding='utf-8'))
   vector = compute_vector(d)
   novo_perfil = {KEY_FIELD: pid, "vector": {axis: vector[axis] for axis in AXIS_ORDER}}

   profiles = json.load(open(PROFILES_FILE, encoding='utf-8'))
   if pid not in {p[KEY_FIELD] for p in profiles}:
       profiles.append(novo_perfil)
   else:
       # perfil já existia (reaudit) — atualiza em vez de duplicar
       for p in profiles:
           if p[KEY_FIELD] == pid:
               p['vector'] = novo_perfil['vector']

   with open(PROFILES_FILE, 'w', encoding='utf-8') as f:
       json.dump(profiles, f, ensure_ascii=False, indent=2)
       f.write('\n')
   ```

6. Copie `subagent-out/<catalog>/<id>.json` para `answers/<catalog>/<id>.json` (arquivo permanente,
   nunca apagar). Apague o `prompts/<catalog>/<id>.txt` e o `subagent-out/<catalog>/<id>.json`
   temporário depois de arquivar — **a menos que** `prompts/<catalog>/` e `subagent-out/<catalog>/`
   ainda não tenham nenhum exemplo de referência para aquele catálogo, caso em que você mantém esse
   par como o exemplo (mesma regra do passo 7 do README de auditoria).
7. Atualize `profile-audit/STATE.json`: adicione o novo `id` em `STATE.json.<catalog>.done` (ele
   nunca esteve em `pending`, porque é um perfil novo, não um reaudit) e incremente
   `STATE.json.<catalog>.totalProfiles` em 1. Atualize `lastUpdated`.

## Passo 6 — Rodar e testar tudo

1. Rode a suíte de testes do backend (o comando de referência já documentado em
   `match-explained.md`, adapte para rodar a suíte completa em vez de só os testes de scoring):

   ```powershell
   cd backend
   ..\.tools\apache-maven-3.9.15\bin\mvn.cmd test
   ```

   Se esse caminho do Maven não existir neste ambiente, procure o wrapper/instalação disponível
   (`mvnw`, `mvnw.cmd`, ou um `mvn` já no PATH) antes de desistir. Informe o usuário se não
   conseguir localizar nenhum executor de Maven.

2. Preste atenção especial aos testes que validam exatamente o que este processo acabou de criar:
   - `IdeologyPersonalityMappingTest` (só relevante se você criou/editou uma ideologia ou
     personalidade): confere que toda ideologia aponta para uma personalidade existente, que toda
     personalidade tem perfil explícito, metadados válidos e imagem existente em
     `frontend/public/...`.
   - `IdeologyCountryMappingTest` (relevante para country/ideology): confere que todo país tem
     perfil explícito com os 12 eixos válidos.
   - `ProfileMatchScorerTest` / `ScorerBenchmarkTest`: não deveriam quebrar com a adição de um
     perfil novo, mas rode mesmo assim — um vetor mal calculado (fora de 0-100, eixo faltando) quebra
     essas suítes também.
   - `QuizFlowAutomationTest`, `SharedResultsTest`: contrato geral da API, garantem que nada mais
     quebrou.

3. Se algum teste falhar, **não ignore nem pule** — volte ao passo correspondente (metadados,
   imagem, ou vetor) e corrija a causa raiz antes de prosseguir.

4. Depois que os testes passarem, rode a aplicação localmente e verifique visualmente o novo
   perfil aparecendo corretamente no fluxo de resultado, se você tiver acesso a rodar o
   frontend/backend juntos neste ambiente. Se não tiver, diga isso explicitamente ao usuário em vez
   de alegar que testou visualmente.

## Passo 7 — Calcular os perfis mais compatíveis nos três catálogos

Depois que o vetor do novo perfil estiver mesclado no arquivo de perfis (passo 5), rode o script
utilitário que reproduz exatamente o algoritmo de `ProfileMatchScorer.java` (mesmos pesos e
fórmulas de `axisSimilarity`/`directionSimilarity`/`magnitudeSimilarity`/`outlierSimilarity`):

```powershell
python profile-audit/compatibility.py <catalog> <id>
```

Exemplo: `python profile-audit/compatibility.py personality zohran-mamdani`.

O script aplica a **regra do filtro de religião** (espelho de `ReligionFilter.java`): por padrão
calcula o ranking como o usuário que escolheu a(s) religião(ões) selecionável(is) do próprio perfil
(`religions` do JSON PT), uma seção por religião, escondendo perfis marcados só com outra tradição
(ex.: um perfil cristão não vê "Democracia Islâmica"); perfil secular (`[]` ou só `other`) sai sem
filtro. `--religion <valor>` força uma preferência e `--sem-filtro` devolve o ranking geral. Use no
resumo do passo 8 a saída filtrada, que é o que o usuário real veria.

O script imprime o top 2 de cada catálogo. Ao calcular compatibilidade para uma ideologia, imprime
as **3 ideologias mais próximas com suas categorias cadastradas**, além do top 2 de personalidades e
países. Guarde essa saída para o resumo do passo 8 — **nunca estime esses matches de cabeça**, pois
o cálculo combina similaridade por eixo, direção, magnitude e outliers com pesos diferentes.

Ao criar ou reauditar uma ideologia, use os três vizinhos e suas categorias como evidência na revisão
de categoria **depois do merge** do vetor. Registre categoria atual/proposta, compatibilidades exatas,
argumentos favoráveis e contrários em `profile-audit/reports/category-reviews/<id>.md`, conforme
[`IDEOLOGY_CATEGORY_REVIEW.md`](IDEOLOGY_CATEGORY_REVIEW.md). Os vizinhos guiam a revisão, mas não
alteram automaticamente a categoria: se a proposta divergir da atual, peça confirmação explícita.

## Passo 8 — Apresentar a nova inclusão ao usuário

Feche o processo com um resumo direto ao usuário contendo:

- Catálogo e `id`/`name` do novo perfil.
- Resumo de 1-2 frases do vetor resultante (ex.: quais eixos ficaram mais extremos e para qual
  lado, comparando com perfis conhecidos do mesmo catálogo se ajudar a dar contexto).
- Os matches calculados no passo 7, com percentuais exatos: normalmente dois de cada catálogo; para
  uma ideologia, dois de personalidade, três ideologias com categorias e dois países (nunca estime).
- As alternativas escolhidas nas perguntas de arquétipo (bloco `archetype` da saída do passo 5).
- Confirmação de que os testes relevantes passaram (ou lista exata do que falhou e não pôde ser
  corrigido, se for o caso).
- Lista dos arquivos tocados nesta execução (metadados PT, metadados EN, perfil com vetor, arquivo
  de imagem se aplicável, `STATE.json`, `answers/<catalog>/<id>.json`).

## Regras que não podem ser quebradas

- **Nunca** invente/estime um vetor sem rodar o processo de auditoria pergunta-a-pergunta do passo
  5 — é a mesma regra do `profile-audit/README.md`: cada perfil precisa das 240 respostas reais
  simuladas por um modelo de qualidade, nunca um atalho.
- **Nunca** use um modelo fraco/rápido (tipo Haiku) para gerar as respostas de auditoria.
- **Nunca** deixe um `id` duplicado entre metadados PT e EN, ou entre um catálogo e outro.
- **Nunca** afirme que uma imagem foi baixada ou que testes passaram sem de fato ter feito isso —
  se algo não pôde ser verificado neste ambiente, diga isso claramente ao usuário.
- **Nunca** apague nem sobrescreva arquivos dentro de `profile-audit/answers/<catalog>/` — mesma
  regra do processo de auditoria.
- Sempre que possível, **rode os testes de verdade** antes de declarar a criação do perfil como
  concluída — ver `superpowers:verification-before-completion` se disponível como skill.
